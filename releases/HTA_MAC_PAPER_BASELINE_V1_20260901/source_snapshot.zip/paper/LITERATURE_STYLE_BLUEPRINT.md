# Literature and presentation blueprint

## Scope

The manuscript is positioned against fifteen closely related energy-harvesting
MAC, scheduling, and reinforcement-learning studies. The comparison is
methodological rather than numerical because their radio models, traffic,
topologies, horizons, and reported endpoints are not interchangeable.

## Writing pattern adopted

The strongest papers follow a consistent sequence:

1. define the operational tradeoff before naming the algorithm;
2. state a small number of falsifiable contributions;
3. introduce only equations that are later measured or constrained;
4. separate the system model from the learning approximation;
5. explain each figure with one quantitative observation; and
6. close with limitations that narrow, rather than repeat, the claims.

Iannello *et al.* are the clearest model for tradeoff-first exposition: delivery
probability and time efficiency are defined before protocol comparisons, and
their figures place both quantities on the same operating plane. Gong *et al.*
similarly formulate channel utilization before presenting their assignment
solver. HENO-MAC uses a compact gap--mechanism--real-trace--result abstract and
connects every energy equation to a protocol threshold. The recent clustered
DRL study by Hasani *et al.* uses a network schematic, a parameter table, a
Bellman-loss equation, and node-count transfer plots, but illustrates why the
present manuscript must add paired uncertainty and avoid unsupported uses of
“significant.” Eriş *et al.* provide the closest adaptive TDMA/RL comparison
and explicitly report FND, HND, and LND; their discussion also acknowledges
where learning does not improve the earliest death metric.

## Reporting terminology

The main paper follows normal experimental-language conventions rather than
provenance-log terminology. It reports the training procedure, the number of
independent evaluation runs, the held-out status of those runs, paired common
randomness, and the statistical unit. Exact pseudorandom identifiers,
checksums, artifact gates, and transfer-time integrity instructions belong in
the reproducibility archive. The word “frozen” is replaced by “predefined,”
“held fixed,” or “held out” according to the scientific meaning.

The retained controller is described as one **two-stage training pipeline**:
QoS-distilled initialization followed by task-specific fine-tuning. Calling it
a single training run would conceal the warm start and would be inaccurate.
Conversely, recounting every unsuccessful implementation attempt would obscure
the method. Only the workload-context ablation is retained because its negative
held-out result informs the scientific interpretation of the high-load gap.

## Equation policy

The paper therefore keeps five equation groups only:

- radio and idle-listening energy;
- battery and queue evolution;
- the constrained slot-allocation objective and QoS metrics;
- the permutation-equivariant distributional value model; and
- the marginal-value budget projection.

Every symbol is defined locally. Training-only implementation detail is
excluded unless it changes the scientific method. Standard equations are
cited to their primary sources; project-specific equations are presented as
model definitions, not universal physical laws.

## Figure policy

Four visual roles are sufficient for the main paper:

- a system-and-policy diagram to establish causal scope;
- an architecture diagram to make equivariance and projection visible;
- a forest plot for the ten paired delivery effects; and
- a two-panel delivery--lifetime plot for the reference and 20-node regimes.

The remaining transfer matrix belongs in a table. Training curves are omitted
because the scientific claim is based on held-out evaluation, not on
visual convergence. Figures use direct labels, color-blind-safe colors, and
captions that state the inference unit and uncertainty method.

## Claim boundary

The paper may claim robust delivery improvement over energy-proportional
allocation across the predefined ten-scenario matrix, a 20-node lifetime gain, and
practical non-inferiority to the online primal--dual baseline under declared
margins. It must not claim universal lifetime superiority, equivalence to the
primal--dual controller, field validation, or end-to-end cluster-head
optimization.
