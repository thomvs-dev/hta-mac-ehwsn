"""Create compact vector figures for the HTA-MAC manuscript."""

from pathlib import Path
import json
import sys
import time

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
OUT = Path(__file__).resolve().parent / "figures"
OUT.mkdir(parents=True, exist_ok=True)

BLUE = "#1565C0"
ORANGE = "#E66101"
GREEN = "#2E7D32"
INK = "#263238"
PALE = "#EEF4FA"
RED = "#B2182B"


def bootstrap_mean_ci(values, *, rng, resamples=20000):
    values = np.asarray(values, dtype=np.float64)
    draws = rng.choice(values, size=(resamples, values.size), replace=True).mean(axis=1)
    return [float(np.percentile(draws, 2.5)), float(np.percentile(draws, 97.5))]


def box(ax, xy, width, height, text, color=BLUE, size=9):
    patch = FancyBboxPatch(
        xy, width, height, boxstyle="round,pad=0.02,rounding_size=0.025",
        linewidth=1.2, edgecolor=color, facecolor="white"
    )
    ax.add_patch(patch)
    ax.text(xy[0] + width / 2, xy[1] + height / 2, text,
            ha="center", va="center", fontsize=size, color=INK)


def arrow(ax, start, end, color=INK):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=11,
                                linewidth=1.1, color=color))


def architecture():
    fig, ax = plt.subplots(figsize=(7.15, 3.0))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    box(ax, (0.02, 0.57), 0.17, 0.25,
        "Per-node state\nenergy, queue, forecast,\nCH-role context")
    box(ax, (0.25, 0.57), 0.16, 0.25, "Shared node\nencoder")
    box(ax, (0.47, 0.71), 0.16, 0.17, "Masked mean\nand max pooling", GREEN)
    box(ax, (0.47, 0.43), 0.16, 0.17, "Local node\nembedding", GREEN)
    box(ax, (0.69, 0.57), 0.14, 0.25,
        "Dueling C51\nvalue + shared\nadvantage head", ORANGE)
    box(ax, (0.87, 0.57), 0.11, 0.25, "Marginal-Q\nbudget\nprojection", ORANGE, 8)
    box(ax, (0.69, 0.12), 0.29, 0.18,
        "Feasible slot vector  $a_i\\in\\{0,1,2,3\\}$,  $\\sum_i a_i\\leq B$", BLUE, 9)
    for y in (0.64, 0.75):
        arrow(ax, (0.19, y), (0.25, y))
    arrow(ax, (0.41, 0.72), (0.47, 0.79))
    arrow(ax, (0.41, 0.65), (0.47, 0.51))
    arrow(ax, (0.63, 0.79), (0.69, 0.74))
    arrow(ax, (0.63, 0.51), (0.69, 0.64))
    arrow(ax, (0.83, 0.70), (0.87, 0.70))
    arrow(ax, (0.925, 0.57), (0.84, 0.30))
    ax.text(0.50, 0.96, "Permutation-equivariant distributional slot allocation",
            ha="center", va="center", fontsize=12, weight="bold", color=INK)
    ax.text(0.23, 0.36, "The same encoder and advantage function are used for every node;\n"
            "set pooling carries cluster context without encoding node order.",
            ha="left", va="center", fontsize=8.5, color=INK)
    fig.tight_layout(pad=0.2)
    fig.savefig(OUT / "hta_architecture.pdf", bbox_inches="tight")
    fig.savefig(OUT / "hta_architecture.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def system_scope():
    fig, ax = plt.subplots(figsize=(7.15, 3.0))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    # Cluster and nodes
    ax.add_patch(Circle((0.25, 0.52), 0.26, facecolor=PALE, edgecolor=BLUE, lw=1.3))
    nodes = [(0.10, 0.64), (0.17, 0.38), (0.27, 0.70), (0.35, 0.40), (0.40, 0.62)]
    for idx, (x, y) in enumerate(nodes):
        ax.add_patch(Circle((x, y), 0.026, color=GREEN))
        ax.text(x, y - 0.065, f"$v_{idx+1}$", ha="center", fontsize=8)
    ax.add_patch(Circle((0.25, 0.52), 0.042, color=ORANGE))
    ax.text(0.25, 0.45, "scheduled CH", ha="center", fontsize=8)
    for x, y in nodes:
        arrow(ax, (x, y), (0.23 + 0.05*(x > 0.25), 0.52), BLUE)
    ax.add_patch(Circle((0.76, 0.58), 0.052, color=INK))
    ax.text(0.76, 0.49, "base station", ha="center", fontsize=8)
    arrow(ax, (0.29, 0.53), (0.70, 0.58), ORANGE)
    box(ax, (0.52, 0.12), 0.40, 0.18,
        "HTA-MAC changes only member slot/sleep decisions\n"
        "CH rotation, association, and routing remain exogenous", BLUE, 9)
    arrow(ax, (0.48, 0.49), (0.66, 0.30), INK)
    ax.text(0.50, 0.93, "Causal scope of the clustered EH-WSN experiment",
            ha="center", fontsize=12, weight="bold", color=INK)
    ax.text(0.25, 0.17, "Each round: harvest $\\rightarrow$ allocate slots $\\rightarrow$\n"
            "member transmission $\\rightarrow$ CH aggregation/forwarding",
            ha="center", va="center", fontsize=8.5, color=INK)
    fig.tight_layout(pad=0.2)
    fig.savefig(OUT / "system_scope.pdf", bbox_inches="tight")
    fig.savefig(OUT / "system_scope.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def compact_pareto():
    data = json.loads((ROOT / "outputs/phase4/final_confirmation_v1/final_confirmation.json").read_text())
    corrected = json.loads((ROOT / "outputs/phase4/cap_corrected_energy_audit_v1/results.json").read_text())
    labels = {"hta_mac": "HTA-MAC", "energy_proportional": "Energy-proportional",
              "online_primal_dual": "Online primal-dual"}
    colors = {"hta_mac": BLUE, "energy_proportional": ORANGE,
              "online_primal_dual": GREEN}
    fig, axes = plt.subplots(1, 2, figsize=(7.15, 2.9))
    for ax, scenario, title in zip(axes, ("reference_100", "nodes_20"),
                                   ("Reference: 100 nodes", "Transfer: 20 nodes")):
        for policy in labels:
            mean = (
                corrected["results"][scenario]["corrected_energy_mean"]
                if policy == "energy_proportional"
                else data["results"][scenario]["policies"][policy]["mean"]
            )
            ax.scatter(mean["delivery_ratio"], mean["restricted_survival_rounds"],
                       s=62, color=colors[policy], label=labels[policy], zorder=3)
        ax.set_title(title, fontsize=10)
        ax.set_xlabel("Delivery ratio")
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("Restricted survival time (rounds)")
    handles, legend_labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc="upper center", ncol=3, frameon=False,
               bbox_to_anchor=(0.5, 1.04), fontsize=8.5)
    fig.tight_layout(rect=(0, 0, 1, 0.90), w_pad=1.5)
    fig.savefig(OUT / "reference_nodes20_pareto.pdf", bbox_inches="tight")
    fig.savefig(OUT / "reference_nodes20_pareto.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def scalability_performance(stats):
    data = json.loads(
        (ROOT / "outputs/phase4/node_scalability_50_300_v1/results.json").read_text()
    )
    scenarios = [(nodes, f"nodes_{nodes}") for nodes in range(50, 301, 50)]
    policies = ["hta_mac", "energy_proportional", "online_primal_dual"]
    labels = {"hta_mac": "HTA-MAC", "energy_proportional": "Energy-proportional",
              "online_primal_dual": "Online primal-dual"}
    colors = {"hta_mac": BLUE, "energy_proportional": ORANGE,
              "online_primal_dual": GREEN}
    markers = {"hta_mac": "o", "energy_proportional": "s", "online_primal_dual": "^"}
    metrics = [
        ("delivery_ratio", "Delivery ratio"),
        ("stale_ratio", "Stale-drop ratio"),
        ("fairness", "Service fairness"),
        ("restricted_survival_rounds", "Restricted survival (rounds)"),
        ("packets_per_j", "Packets/J"),
    ]
    rng = np.random.default_rng(20260829)
    output = {}
    fig, axes = plt.subplots(2, 3, figsize=(7.15, 4.55))
    flat_axes = axes.ravel()
    for ax, (metric, ylabel) in zip(flat_axes, metrics):
        output[metric] = {}
        for policy in policies:
            means, lows, highs = [], [], []
            output[metric][policy] = {}
            for nodes, scenario in scenarios:
                summaries = data["results"][scenario]["policies"][policy]["seed_summaries"]
                values = [float(row[metric]) for row in summaries.values()]
                mean = float(np.mean(values))
                ci = bootstrap_mean_ci(values, rng=rng)
                means.append(mean); lows.append(mean - ci[0]); highs.append(ci[1] - mean)
                output[metric][policy][str(nodes)] = {"mean": mean, "bootstrap_95_ci": ci}
            ax.errorbar(
                [x[0] for x in scenarios], means, yerr=[lows, highs],
                color=colors[policy], marker=markers[policy], ms=4.2, lw=1.25,
                capsize=2.4, label=labels[policy],
            )
        ax.set_xlabel("Network nodes")
        ax.set_ylabel(ylabel)
        ax.set_xticks([50, 100, 150, 200, 250, 300])
        ax.grid(alpha=0.22)
    flat_axes[-1].axis("off")
    handles, legend_labels = flat_axes[0].get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc="upper center", ncol=3, frameon=False,
               bbox_to_anchor=(0.5, 1.06), fontsize=8.2)
    fig.tight_layout(rect=(0, 0, 1, 0.91), w_pad=1.0)
    fig.savefig(OUT / "scalability_performance.pdf", bbox_inches="tight")
    fig.savefig(OUT / "scalability_performance.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    stats["scalability_policy_means"] = output
    stats["scalability_paired_hta_minus_energy"] = {
        str(nodes): {
            metric: data["results"][scenario]["comparisons"]["energy_proportional"][metric]
            for metric in ("delivery_ratio", "restricted_survival_rounds", "packets_per_j_relative")
        }
        for nodes, scenario in scenarios
    }
    stats["scalability_paired_hta_minus_online_primal_dual"] = {
        str(nodes): {
            metric: data["results"][scenario]["comparisons"]["online_primal_dual"][metric]
            for metric in ("delivery_ratio", "stale_ratio", "fairness",
                           "restricted_survival_rounds", "packets_per_j_relative")
        }
        for nodes, scenario in scenarios
    }


def robustness_multimetric(stats):
    data = json.loads(
        (ROOT / "outputs/phase4/cap_corrected_energy_audit_v1/results.json").read_text()
    )
    scenarios = [
        ("reference_100", "Reference"), ("nodes_20", "20 nodes"),
        ("nodes_50", "50 nodes"), ("traffic_low", "Low traffic"),
        ("traffic_high", "High traffic"), ("harvest_low", "Low harvest"),
        ("harvest_high", "High harvest"), ("battery_half", "Half battery"),
        ("field_large", "Large field"), ("external_trace_srrl_2020", "PVGIS trace"),
    ]
    metrics = [
        ("delivery_ratio", "Delivery-ratio difference"),
        ("restricted_survival_rounds", "Survival difference (rounds)"),
        ("packets_per_j_relative", "Relative packets/J difference"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(7.15, 4.15), sharey=True)
    y = np.arange(len(scenarios))
    output = {}
    for ax, (metric, xlabel) in zip(axes, metrics):
        means, lo, hi = [], [], []
        output[metric] = {}
        for scenario, label in scenarios:
            item = data["results"][scenario]["comparison"][metric]
            mean = float(item["mean_difference"]); ci = item["bootstrap_95_ci"]
            means.append(mean); lo.append(mean - ci[0]); hi.append(ci[1] - mean)
            output[metric][scenario] = item
        colors = [BLUE if value >= 0 else RED for value in means]
        ax.errorbar(means, y, xerr=[lo, hi], fmt="none", ecolor=INK, elinewidth=1,
                    capsize=2, zorder=1)
        ax.scatter(means, y, c=colors, s=22, zorder=2)
        ax.axvline(0, color="0.35", ls="--", lw=0.9)
        ax.set_xlabel(xlabel, fontsize=8.2)
        ax.grid(axis="x", alpha=0.20)
    axes[0].set_yticks(y, [x[1] for x in scenarios], fontsize=8)
    axes[0].invert_yaxis()
    fig.suptitle("HTA-MAC minus cap-corrected energy allocation: paired means and 95% CIs", fontsize=9.6)
    fig.tight_layout(rect=(0, 0, 1, 0.96), w_pad=0.7)
    fig.savefig(OUT / "robustness_multimetric.pdf", bbox_inches="tight")
    fig.savefig(OUT / "robustness_multimetric.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    stats["robustness_paired_hta_minus_cap_corrected_energy"] = output


def ablation_evidence(stats):
    fair = json.loads(
        (ROOT / "outputs/phase4/publication_extension_v1/fair_energy_pilot_reanalysis.json").read_text()
    )
    training = json.loads(
        (ROOT / "outputs/phase4/publication_extension_v1/training_full.json").read_text()
    )
    left_policies = ["hta_mac", "hta_no_ch_context", "hta_no_set_context",
                     "online_primal_dual", "energy_proportional"]
    left_labels = ["HTA-MAC", "No CH context", "No set context", "Primal-dual", "Energy-prop."]
    lrfer = fair["analysis"]["cross_scenario_load_robustness"]["policies"]
    means = [lrfer[p]["mean_retention"] for p in left_policies]
    cis = [lrfer[p]["bootstrap_95_ci"] for p in left_policies]
    y = np.arange(len(left_policies))

    variant_order = ["full", "no_ch_context", "no_trajectory_loss",
                     "no_concavity_loss", "no_auxiliary_losses"]
    short = ["Full", "No CH", "No traj.", "No concav.", "No aux."]
    grouped = {variant: [] for variant in variant_order}
    for lineage in training["lineages"]:
        grouped[lineage["variant"]].append(lineage)
    pass_counts, collapse_counts = [], []
    for variant in variant_order:
        passes = 0; collapses = 0
        for lineage in grouped[variant]:
            summary_path = ROOT / "outputs/phase2" / lineage["run_name"] / "summary.json"
            summary = json.loads(summary_path.read_text())
            passes += int(bool(summary.get("phase2_curriculum_gate_pass")))
            collapses += int(bool(summary.get("always_sleep_collapse")))
        pass_counts.append(passes); collapse_counts.append(collapses)

    fig, axes = plt.subplots(1, 2, figsize=(7.15, 2.75))
    lo = [m - c[0] for m, c in zip(means, cis)]
    hi = [c[1] - m for m, c in zip(means, cis)]
    axes[0].errorbar(means, y, xerr=[lo, hi], fmt="o", color=BLUE,
                     ecolor=INK, capsize=2.5, ms=4.5)
    axes[0].set_yticks(y, left_labels, fontsize=8)
    axes[0].invert_yaxis()
    axes[0].set_xlabel("LRFER (high traffic / reference)")
    axes[0].set_title("Same-checkpoint intervention (5 pairs)", fontsize=9)
    axes[0].grid(axis="x", alpha=0.22)

    x = np.arange(len(variant_order)); width = 0.35
    axes[1].bar(x - width / 2, pass_counts, width, label="Gate pass", color=GREEN)
    axes[1].bar(x + width / 2, collapse_counts, width, label="All-sleep", color=RED)
    axes[1].set_xticks(x, short, rotation=25, ha="right", fontsize=8)
    axes[1].set_ylim(0, 3.35); axes[1].set_yticks([0, 1, 2, 3])
    axes[1].set_ylabel("Lineages out of 3")
    axes[1].set_title("Matched optimization stability", fontsize=9)
    axes[1].legend(frameon=False, fontsize=8)
    axes[1].grid(axis="y", alpha=0.22)
    fig.tight_layout(w_pad=1.2)
    fig.savefig(OUT / "ablation_evidence.pdf", bbox_inches="tight")
    fig.savefig(OUT / "ablation_evidence.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    stats["ablation"] = {
        "same_checkpoint_lrfer": {p: lrfer[p] for p in left_policies},
        "training_lineages": {
            variant: {"lineages": len(grouped[variant]), "gate_passes": pass_counts[i],
                      "all_sleep_collapses": collapse_counts[i]}
            for i, variant in enumerate(variant_order)
        },
    }


def complexity_profile(stats):
    import torch
    from agents.architectures import (
        EquivariantSetBranchingC51, GlobalBranchingDuelingC51, IndependentDuelingC51,
    )
    from agents.budget_projection import project_slot_budget

    checkpoint_path = ROOT / "outputs/phase2/step3_primary_idle_hybrid_100ep_opt6801_cpu6/branching_c51.pt"
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    cfg = checkpoint["config"]
    capacities = [20, 50, 100]
    parameter_counts = {"equivariant": [], "global_head": [], "independent": []}
    for capacity in capacities:
        models = {
            "equivariant": EquivariantSetBranchingC51(
                input_dim=cfg["input_dim"], actions=cfg["actions"], atoms=cfg["atoms"],
                budget=cfg["budget"], max_branches=capacity,
            ),
            "global_head": GlobalBranchingDuelingC51(
                input_dim=cfg["input_dim"], actions=cfg["actions"], atoms=cfg["atoms"],
                max_branches=capacity,
            ),
            "independent": IndependentDuelingC51(
                input_dim=cfg["input_dim"], actions=cfg["actions"], atoms=cfg["atoms"],
                max_branches=capacity,
            ),
        }
        for name, model in models.items():
            parameter_counts[name].append(sum(p.numel() for p in model.parameters()))

    model = EquivariantSetBranchingC51(
        input_dim=cfg["input_dim"], actions=cfg["actions"], atoms=cfg["atoms"],
        v_min=cfg["v_min"], v_max=cfg["v_max"], budget=cfg["budget"],
        max_branches=cfg["max_branches"],
    )
    model.load_state_dict(checkpoint["online_state_dict"]); model.eval()
    torch.set_num_threads(1)
    branch_counts = [10, 20, 50, 100]
    medians, intervals = [], []
    for branches in branch_counts:
        generator = torch.Generator().manual_seed(20260829 + branches)
        state = torch.randn((1, branches, cfg["input_dim"]), generator=generator)
        mask = torch.ones((1, branches), dtype=torch.bool)

        def one_decision():
            with torch.inference_mode():
                q_values = model.q_values(state, mask)[0].numpy()
            project_slot_budget(q_values, cfg["budget"])

        for _ in range(100):
            one_decision()
        blocks = []
        for _ in range(30):
            start = time.perf_counter_ns()
            for _ in range(100):
                one_decision()
            blocks.append((time.perf_counter_ns() - start) / 100.0 / 1e6)
        medians.append(float(np.median(blocks)))
        intervals.append([float(np.percentile(blocks, 2.5)), float(np.percentile(blocks, 97.5))])

    fig, axes = plt.subplots(1, 2, figsize=(7.15, 2.65))
    labels = {"equivariant": "Equivariant shared", "global_head": "Global + branch heads",
              "independent": "Independent DQNs"}
    colors = {"equivariant": BLUE, "global_head": ORANGE, "independent": GREEN}
    for name in parameter_counts:
        mib = np.asarray(parameter_counts[name]) * 4 / (1024 ** 2)
        axes[0].plot(capacities, mib, marker="o", ms=4, color=colors[name], label=labels[name])
    axes[0].set_xlabel("Branch capacity")
    axes[0].set_ylabel("FP32 parameter memory (MiB)")
    axes[0].set_xticks(capacities); axes[0].grid(alpha=0.22)
    axes[0].legend(frameon=False, fontsize=7.5)

    lo = [m - c[0] for m, c in zip(medians, intervals)]
    hi = [c[1] - m for m, c in zip(medians, intervals)]
    axes[1].errorbar(branch_counts, medians, yerr=[lo, hi], marker="o", color=BLUE,
                     capsize=2.5, lw=1.25)
    axes[1].set_xlabel("Active branches")
    axes[1].set_ylabel("Decision latency (ms)")
    axes[1].set_xticks(branch_counts); axes[1].grid(alpha=0.22)
    axes[1].set_title("Single-thread CPU; network + projection", fontsize=8.5)
    fig.tight_layout(w_pad=1.2)
    fig.savefig(OUT / "complexity_profile.pdf", bbox_inches="tight")
    fig.savefig(OUT / "complexity_profile.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    stats["complexity"] = {
        "parameter_counts": {name: dict(zip(map(str, capacities), values))
                             for name, values in parameter_counts.items()},
        "hta_fp32_parameter_memory_mib": parameter_counts["equivariant"][-1] * 4 / (1024 ** 2),
        "latency_protocol": "30 blocks of 100 decisions after 100 warm-ups; torch.set_num_threads(1)",
        "torch_version": torch.__version__,
        "branch_latency_ms": {
            str(branches): {"median": medians[i], "block_percentile_95_interval": intervals[i]}
            for i, branches in enumerate(branch_counts)
        },
    }


if __name__ == "__main__":
    stats = {"schema_version": 1, "generated_from_existing_artifacts": True}
    architecture()
    system_scope()
    compact_pareto()
    scalability_performance(stats)
    robustness_multimetric(stats)
    ablation_evidence(stats)
    complexity_profile(stats)
    (Path(__file__).resolve().parent / "evaluation_extension_stats.json").write_text(
        json.dumps(stats, indent=2) + "\n", encoding="utf-8"
    )
