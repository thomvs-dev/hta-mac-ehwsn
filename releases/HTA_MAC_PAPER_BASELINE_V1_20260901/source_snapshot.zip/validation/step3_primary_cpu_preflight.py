"""Primary idle-on/hybrid runtime, schema, and equivariance preflight."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import experiments.train_phase2_dynamic_curriculum as trainer
import experiments.audit_phase2d_foundation as foundation_audit
from agents.ch_depletion_risk import validate_ch_risk_config
from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from core.runtime_fingerprint import make_runtime_contract
from envs.step3_lifetime_env import RoleSeparatedScheduledMACEnv, configure_step3_risk
from envs.step3_policy_observation import STEP3_CH_CONTEXT_SCHEMA
from envs.step3_v3_env import Step3V3DynamicClusterTrainingEnv
from experiments.audit_phase2d_foundation import compare, load_agent, summarize
from experiments.train_phase2_dynamic_curriculum import padded_state


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stable_network_outputs(agent, state, mask):
    """Evaluate C51 expectation in float64 without changing network logits."""
    state_t = torch.as_tensor(state, dtype=torch.float32).unsqueeze(0)
    mask_t = torch.as_tensor(mask, dtype=torch.bool).unsqueeze(0)
    with torch.no_grad():
        transformed = agent._transform_state_tensor(state_t)
        log_probabilities = agent.online(transformed, mask_t)[0].cpu().numpy()
    support = agent.online.support.detach().cpu().numpy().astype(np.float64)
    q_values = (
        np.exp(log_probabilities.astype(np.float64))
        * support[None, None, :]
    ).sum(axis=-1)
    return log_probabilities, q_values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--oracle-report", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--ch-risk-config", type=Path, required=True)
    parser.add_argument("--step3-qos-config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-contract-output", type=Path, required=True)
    parser.add_argument("--optimizer-seed", type=int, required=True)
    args = parser.parse_args()
    resolve = lambda path: path if path.is_absolute() else ROOT / path
    oracle, checkpoint, risk_path, qos_path, output, runtime_path = map(resolve, (
        args.oracle_report, args.checkpoint, args.ch_risk_config,
        args.step3_qos_config, args.output, args.runtime_contract_output,
    ))
    oracle_payload = json.loads(oracle.read_text())
    risk = validate_ch_risk_config(json.loads(risk_path.read_text()))
    Step3QoSConstraintConfig.from_payload(json.loads(qos_path.read_text()))
    configure_step3_risk(risk)
    trainer.ScheduledIntraClusterMACEnv = RoleSeparatedScheduledMACEnv
    trainer.DynamicClusterTrainingEnv = Step3V3DynamicClusterTrainingEnv
    envs, manifest, cfg = trainer.build_curriculum(
        [2400], 5, observation_schema=STEP3_CH_CONTEXT_SCHEMA,
        environment_profile=None,
    )
    env = envs[0]
    observation, _, _ = env.reset()
    before = observation[:, 26].copy()
    env.base.energy[int(env.ch)] *= 0.5
    after = env._observation(env.base._state())[:, 26]
    foundation_audit.PHASE2D_POLICY_SCHEMA = STEP3_CH_CONTEXT_SCHEMA
    foundation_audit.network_outputs = stable_network_outputs
    agent, _ = load_agent(checkpoint)
    agent.reinitialize_categorical_outputs(seed=int(args.optimizer_seed))
    state, active, caps = padded_state(env, observation, env._mask(), env.base.n_nodes)
    rng = np.random.default_rng(20260812)
    priorities = np.arange(env.base.n_nodes, dtype=np.int64)
    active_nodes = np.flatnonzero(active)
    records = []
    for index in range(5):
        permutation = np.arange(env.base.n_nodes, dtype=np.int64)
        shuffled = active_nodes.copy()
        rng.shuffle(shuffled)
        permutation[active_nodes] = shuffled
        records.append(compare(
            agent, state, active, caps, priorities, permutation,
            "post_reinitialization_random", index,
        ))
    foundation = summarize(records)
    foundation_pass = bool(
        foundation["maximum_log_probability_error"] <= 1e-6
        and foundation["maximum_q_error"] <= 1e-6
        and foundation["mean_local_argmax_agreement"] == 1.0
        and foundation["mean_projected_allocation_agreement"] == 1.0
        and foundation["all_allocations_feasible"]
    )
    gates = {
        "oracle_capacity_authorized": oracle_payload.get("training_candidate_authorized") is True,
        "schema_is_v3": env.observation_schema == STEP3_CH_CONTEXT_SCHEMA,
        "input_dimension_is_65": observation.shape == (100, 65),
        "embedding_start_is_33": env.observation_layout["embedding_start"] == 33,
        "ch_reserve_is_observable": bool(np.allclose(after, before * 0.5, atol=1e-6)),
        "primary_idle_enabled": env.base.idle_energy_enabled is True,
        "primary_hybrid_enabled": cfg.solar_scale > 0.0 and cfg.thermal_scale > 0.0,
        "primary_budget_is_24": cfg.frame_slot_budget == 24,
        "schedule_schema_is_frozen_heart_ch": manifest[0]["schedule_schema_version"] == 2,
        "post_reinitialization_same_platform_permutation_foundation": foundation_pass,
    }
    runtime = make_runtime_contract(require_cuda=False)
    runtime_path.parent.mkdir(parents=True, exist_ok=True)
    runtime_path.write_text(json.dumps(runtime, indent=2) + "\n")
    passed = all(gates.values())
    payload = {
        "schema_version": 1,
        "status": "step3_v3_pretraining_pass" if passed else "step3_v3_pretraining_fail",
        "overall_pass": passed,
        "device_scope": "local_cpu_exact_runtime_primary_idle_on_hybrid",
        "runtime_fingerprint_sha256": runtime["fingerprint_sha256"],
        "ch_risk_config_sha256": sha256(risk_path),
        "qos_config_sha256": sha256(qos_path),
        "mechanism_report_sha256": sha256(oracle),
        "foundation_checkpoint_sha256": sha256(checkpoint),
        "categorical_output_reinitialization_seed": int(args.optimizer_seed),
        "categorical_outputs_reinitialized_for_gate": True,
        "q_expectation_accumulator": "float64_diagnostic_only",
        "cross_platform_tolerance_validated": False,
        "gates": gates,
        "foundation": foundation,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"status": payload["status"], "gates": gates}, indent=2))
    return 0 if passed else 3


if __name__ == "__main__":
    raise SystemExit(main())
