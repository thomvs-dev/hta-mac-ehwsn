"""Launch three bounded primary lineages concurrently with scoped CPU threads."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def resolve(path):
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path):
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def run_lineage(contract, seed):
    run_name = f"step3_primary_idle_hybrid_100ep_opt{seed}_cpu6"
    log_dir = ROOT / "outputs" / "logs"
    export_dir = ROOT / "outputs" / "local_cpu_export" / run_name
    log_dir.mkdir(parents=True, exist_ok=True)
    export_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = log_dir / f"{run_name}.stdout.log"
    stderr_path = log_dir / f"{run_name}.stderr.log"
    command = [
        sys.executable, "-B", "experiments/train_step3_v3_complete.py",
        "--ch-risk-config", contract["risk_config"],
        "--step3-qos-config", contract["qos_config"],
        "--runtime-contract", contract["runtime_contract"],
        "--preflight-report", contract["preflight_report"],
        "--checkpoint-export-dir", str(export_dir),
        "--episodes", str(contract["episodes"]),
        "--max-steps", str(contract["max_steps"]),
        "--development-seeds", ",".join(map(str, contract["development_seeds"])),
        "--optimizer-seed", str(seed),
        "--run-name", run_name,
        "--device", "cpu",
        "--learn-every", str(contract["learn_every"]),
        "--initial-checkpoint", contract["initial_checkpoint"],
        "--reward-scale-config", contract["reward_scale_config"],
        "--reinitialize-categorical-outputs",
        "--projection-budget", str(contract["projection_budget"]),
        "--architecture", contract["architecture"],
        "--stability-interval", "25",
        "--stability-tail-episodes", "50",
        "--learning-rate", str(contract["learning_rate"]),
        "--normalize-input-blocks",
        "--trajectory-loss-weight", str(contract["trajectory_loss_weight"]),
        "--concavity-loss-weight", str(contract["concavity_loss_weight"]),
        "--precision", contract["precision"],
    ]
    env = os.environ.copy()
    threads = str(contract["threads_per_lineage"])
    env.update({
        "OMP_NUM_THREADS": threads,
        "MKL_NUM_THREADS": threads,
        "OPENBLAS_NUM_THREADS": threads,
        "NUMEXPR_NUM_THREADS": threads,
    })
    started = time.perf_counter()
    with stdout_path.open("w", encoding="utf-8") as stdout, stderr_path.open("w", encoding="utf-8") as stderr:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
    return {
        "optimizer_seed": seed, "run_name": run_name,
        "returncode": result.returncode,
        "elapsed_seconds": time.perf_counter() - started,
        "stdout": str(stdout_path.relative_to(ROOT)),
        "stderr": str(stderr_path.relative_to(ROOT)),
        "run_dir": f"outputs/phase2/{run_name}",
        "export_dir": str(export_dir.relative_to(ROOT)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path, output_path = resolve(args.contract), resolve(args.output)
    contract = json.loads(contract_path.read_text())
    if contract.get("status") != "frozen_before_bounded_primary_training":
        raise RuntimeError("training contract is not frozen")
    for field in (
        "initial_checkpoint", "qos_config", "risk_config", "reward_scale_config",
        "oracle_report", "runtime_contract", "preflight_report",
    ):
        if sha256(contract[field]) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"artifact hash mismatch: {field}")
    if set(contract["development_seeds"]).intersection(contract["prohibited_seeds"]):
        raise RuntimeError("prohibited seed requested")
    started = time.perf_counter()
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=int(contract["parallel_lineages"])) as pool:
        futures = [pool.submit(run_lineage, contract, seed) for seed in contract["optimizer_seeds"]]
        for future in concurrent.futures.as_completed(futures):
            row = future.result()
            results.append(row)
            print(f"LINEAGE_COMPLETE={row['optimizer_seed']} RETURN={row['returncode']}", flush=True)
    results.sort(key=lambda row: row["optimizer_seed"])
    payload = {
        "schema_version": 1,
        "status": "bounded_primary_training_complete",
        "contract_sha256": sha256(contract_path),
        "launcher_sha256": sha256(Path(__file__)),
        "lineages": results,
        "all_processes_completed": all(row["returncode"] in (0, 3) for row in results),
        "all_training_gates_passed": all(row["returncode"] == 0 for row in results),
        "elapsed_seconds": time.perf_counter() - started,
        "longer_training_authorized": False,
        "remaining_confirmation_seeds_opened": False,
        "claim_boundary": contract["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, indent=2), flush=True)
    return 0 if payload["all_processes_completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
