"""Create manuscript-ready plots and a compact CSV from final confirmation."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


LABELS = {
    "reference_100": "Reference (100)",
    "nodes_20": "20 nodes",
    "nodes_50": "50 nodes",
    "traffic_low": "Low traffic",
    "traffic_high": "High traffic",
    "harvest_low": "Low harvest",
    "harvest_high": "High harvest",
    "battery_half": "Half battery",
    "field_large": "Large field",
    "external_trace_srrl_2020": "PVGIS trace",
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    data = json.loads(args.input.read_text())
    args.output_dir.mkdir(parents=True, exist_ok=True)
    scenarios = list(data["results"])

    rows = []
    for scenario in scenarios:
        result = data["results"][scenario]
        hta = result["policies"]["hta_mac"]["mean"]
        energy = result["policies"]["energy_proportional"]["mean"]
        primal = result["policies"]["online_primal_dual"]["mean"]
        effect = result["comparisons"]["energy_proportional"]["delivery_ratio"]
        rows.append({
            "scenario": scenario,
            "hta_delivery": hta["delivery_ratio"],
            "energy_delivery": energy["delivery_ratio"],
            "primal_delivery": primal["delivery_ratio"],
            "hta_rmst": hta["restricted_survival_rounds"],
            "energy_rmst": energy["restricted_survival_rounds"],
            "primal_rmst": primal["restricted_survival_rounds"],
            "hta_packets_per_j": hta["packets_per_j"],
            "energy_packets_per_j": energy["packets_per_j"],
            "primal_packets_per_j": primal["packets_per_j"],
            "delivery_difference": effect["mean_difference"],
            "delivery_ci_low": effect["bootstrap_95_ci"][0],
            "delivery_ci_high": effect["bootstrap_95_ci"][1],
            "holm_p": effect["holm_adjusted_directional_p"],
        })

    csv_path = args.output_dir / "final_confirmation_summary.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    plt.rcParams.update({"font.size": 10, "axes.titlesize": 12})
    figure, axis = plt.subplots(figsize=(8.2, 5.4))
    y = np.arange(len(rows))
    effects = np.asarray([row["delivery_difference"] for row in rows])
    lower = effects - np.asarray([row["delivery_ci_low"] for row in rows])
    upper = np.asarray([row["delivery_ci_high"] for row in rows]) - effects
    axis.errorbar(effects, y, xerr=np.vstack((lower, upper)), fmt="o", color="#1565c0", ecolor="#64b5f6", capsize=3)
    axis.axvline(0.0, color="black", linewidth=0.9, linestyle="--")
    axis.set_yticks(y, [LABELS[row["scenario"]] for row in rows])
    axis.invert_yaxis()
    axis.set_xlabel("Delivery-ratio difference (HTA-MAC minus energy-proportional)")
    axis.set_title("Paired 20-seed delivery effects with bootstrap 95% CIs")
    axis.grid(axis="x", alpha=0.25)
    figure.tight_layout()
    figure.savefig(args.output_dir / "final_delivery_forest.png", dpi=220)
    plt.close(figure)

    figure, axes = plt.subplots(2, 5, figsize=(14.5, 7.2), sharex=False, sharey=False)
    colors = {"HTA-MAC": "#1565c0", "Energy proportional": "#ef6c00", "Online primal-dual": "#2e7d32"}
    for axis, row in zip(axes.flat, rows):
        points = (
            ("HTA-MAC", row["hta_delivery"], row["hta_rmst"]),
            ("Energy proportional", row["energy_delivery"], row["energy_rmst"]),
            ("Online primal-dual", row["primal_delivery"], row["primal_rmst"]),
        )
        for name, delivery, rmst in points:
            axis.scatter(delivery, rmst, s=45, color=colors[name], label=name)
        axis.set_title(LABELS[row["scenario"]])
        axis.set_xlabel("Delivery")
        axis.set_ylabel("RMST (rounds)")
        axis.grid(alpha=0.2)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    figure.suptitle("Delivery--lifetime operating points across the confirmation matrix", y=0.985, fontsize=13)
    figure.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.945), ncol=3, frameon=False)
    figure.tight_layout(rect=(0, 0, 1, 0.88))
    figure.savefig(args.output_dir / "final_delivery_rmst_pareto.png", dpi=220, bbox_inches="tight")
    plt.close(figure)
    print(csv_path)


if __name__ == "__main__":
    main()
