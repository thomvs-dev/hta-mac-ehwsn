"""Create a reviewer-safe HTA-MAC comparison figure.

Panel (a) uses only policies evaluated in the same simulator. Panel (b) maps
published evaluation coverage and explicitly is not a performance leaderboard.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "HTA_MAC_Overleaf_Package"


def relative_change(candidate: float, reference: float) -> float:
    return 100.0 * (candidate - reference) / reference


def stale_reduction(candidate: float, reference: float) -> float:
    return 100.0 * (reference - candidate) / reference


def main() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8.0,
            "axes.titlesize": 9.0,
            "axes.labelsize": 8.0,
            "legend.fontsize": 7.5,
            "xtick.labelsize": 7.5,
            "ytick.labelsize": 7.5,
            "figure.dpi": 160,
            "savefig.dpi": 400,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    hta = {
        "delivery": 0.42770,
        "stale": 0.02476,
        "fairness": 0.94511,
        "survival": 128.28,
        "packets_j": 225.77,
    }
    residual = {
        "delivery": 0.44591,
        "stale": 0.04838,
        "fairness": 0.87166,
        "survival": 149.32,
        "packets_j": 242.36,
    }
    dual = {
        "delivery": 0.43020,
        "stale": 0.01700,
        "fairness": 0.98081,
        "survival": 131.10,
        "packets_j": 232.45,
    }

    metrics = ["Delivery", "Stale reduction", "Jain fairness", "Survival", "Packets/J"]
    versus_residual = np.array(
        [
            relative_change(hta["delivery"], residual["delivery"]),
            stale_reduction(hta["stale"], residual["stale"]),
            relative_change(hta["fairness"], residual["fairness"]),
            relative_change(hta["survival"], residual["survival"]),
            relative_change(hta["packets_j"], residual["packets_j"]),
        ]
    )
    versus_dual = np.array(
        [
            relative_change(hta["delivery"], dual["delivery"]),
            stale_reduction(hta["stale"], dual["stale"]),
            relative_change(hta["fairness"], dual["fairness"]),
            relative_change(hta["survival"], dual["survival"]),
            relative_change(hta["packets_j"], dual["packets_j"]),
        ]
    )

    fig, (ax0, ax1) = plt.subplots(2, 1, figsize=(7.16, 6.35))
    fig.subplots_adjust(left=0.17, right=0.98, top=0.91, bottom=0.12, hspace=0.52)
    fig.suptitle(
        "HTA-MAC: matched performance and published-evidence context",
        fontweight="bold",
        y=0.985,
    )

    y = np.arange(len(metrics))
    height = 0.34
    bars_residual = ax0.barh(
        y - height / 2,
        versus_residual,
        height,
        color="#D97706",
        label="vs. residual-energy greedy (ours)",
    )
    bars_dual = ax0.barh(
        y + height / 2,
        versus_dual,
        height,
        color="#2563A6",
        label="vs. dual-ascent QoS (ours)",
    )
    ax0.axvline(0.0, color="#333333", linewidth=0.8)
    ax0.grid(axis="x", color="#D7D7D7", linewidth=0.5)
    ax0.set_axisbelow(True)
    ax0.set_yticks(y, metrics)
    ax0.invert_yaxis()
    ax0.set_xlim(-52, 55)
    ax0.set_xlabel("HTA-MAC relative change (%)  —  positive means better")
    ax0.set_title("(a) Exact same-simulator comparison, 100-node reference")
    ax0.legend(loc="lower right", frameon=False)

    for bars in (bars_residual, bars_dual):
        for bar in bars:
            value = bar.get_width()
            x = value + (1.0 if value >= 0 else -1.0)
            ax0.text(
                x,
                bar.get_y() + bar.get_height() / 2,
                f"{value:+.1f}%",
                va="center",
                ha="left" if value >= 0 else "right",
                fontsize=7.2,
            )

    # Audit completeness is the sum of four observable reporting properties:
    # repetitions stated, uncertainty reported, multiple node sizes, and
    # multiple outcome metrics. It is intentionally not a quality/performance score.
    papers = [
        ("HTA-MAC", 300, 4, 20, "hta"),
        ("Safe PPO+Guard\n(2026)", 30, 4, 200, "close"),
        ("Hasani DRL\n(2025)", 100, 1, None, "other"),
        ("Eriş TDMA-RL\n(2024)", 100, 3, 100, "other"),
        ("HENO-MAC\n(2024)", 7, 2, None, "other"),
        ("REE-MAC\n(2021)", 20, 3, 50, "other"),
        ("EEMACCSN\n(2015)", 100, 2, None, "other"),
    ]
    colors = {"hta": "#2563A6", "close": "#2F855A", "other": "#777777"}
    markers = {"hta": "D", "close": "s", "other": "o"}
    offsets = {
        "HTA-MAC": (-37, 10),
        "Safe PPO+Guard\n(2026)": (8, 7),
        "Hasani DRL\n(2025)": (-58, 7),
        "Eriş TDMA-RL\n(2024)": (8, 7),
        "HENO-MAC\n(2024)": (8, -4),
        "REE-MAC\n(2021)": (8, 7),
        "EEMACCSN\n(2015)": (8, 7),
    }
    for name, nodes, completeness, repeats, category in papers:
        size = 42 if repeats is None else 42 + 18 * np.log10(repeats + 1)
        ax1.scatter(
            nodes,
            completeness,
            s=size,
            color=colors[category],
            marker=markers[category],
            alpha=0.92,
            edgecolor="white",
            linewidth=0.6,
            zorder=3,
        )
        dx, dy = offsets[name]
        ax1.annotate(name, (nodes, completeness), xytext=(dx, dy), textcoords="offset points", fontsize=7.2)

    ax1.set_xlim(0, 325)
    ax1.set_ylim(0.6, 4.45)
    ax1.set_yticks(
        [1, 2, 3, 4],
        ["1", "2", "3", "4"],
    )
    ax1.set_xlabel("Maximum evaluated node count")
    ax1.set_ylabel("Transparent reporting coverage (0–4)")
    ax1.set_title("(b) Cross-paper evaluation coverage — not a performance leaderboard")
    ax1.grid(color="#D7D7D7", linewidth=0.5)
    ax1.set_axisbelow(True)
    fig.text(
        0.5,
        0.025,
        "Coverage = stated repetitions + uncertainty + multiple node sizes + multiple endpoints.\n"
        "Marker area reflects stated repetition count (log-scaled); unknown repetitions use the minimum size.",
        fontsize=7.0,
        ha="center",
        va="bottom",
    )

    for suffix in ("png", "pdf"):
        fig.savefig(OUTPUT_DIR / f"hta_mac_comparison_context.{suffix}")
    plt.close(fig)


if __name__ == "__main__":
    main()
