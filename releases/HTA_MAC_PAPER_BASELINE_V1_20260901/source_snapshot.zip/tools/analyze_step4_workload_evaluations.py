"""Summarize the frozen Step 4 workload-candidate evaluation artifacts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def aggregate(seed_means):
    rows = list(seed_means.values())
    return {
        key: float(np.mean([row[key] for row in rows]))
        for key in (
            "delivery_ratio", "joint_qos_pass_rate", "restricted_survival_rounds",
            "global_packets", "network_energy_j", "packets_per_j",
        )
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = {"status": "step4_workload_evaluations_analyzed", "lineages": {}}
    for path in args.inputs:
        source = json.loads(path.read_text())
        lineage = path.stem
        scenarios = {}
        for scenario, result in source["results"].items():
            scenarios[scenario] = {
                policy: aggregate(result[policy]["seed_means"])
                for policy in ("candidate", "source", "energy_proportional")
            }
            scenarios[scenario]["candidate_vs_source"] = result["candidate_vs_source"]
        payload["lineages"][lineage] = {
            "candidate": source["candidate"], "candidate_sha256": source["candidate_sha256"],
            "seeds": source["seeds"], "horizon": source["horizon"], "scenarios": scenarios,
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
