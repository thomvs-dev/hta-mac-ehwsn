"""Build and verify the v4 workload-conditioned warm-start checkpoint."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.architectures import warmstart_workload_conditioned
from agents.branching_dqn import BranchingAgentConfig, BranchingDQNAgent
from envs.step3_policy_observation import STEP3_WORKLOAD_CONTEXT_SCHEMA


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--evidence", required=True)
    args = parser.parse_args()

    source_path = Path(args.source).resolve()
    output_path = Path(args.output).resolve()
    evidence_path = Path(args.evidence).resolve()
    checkpoint = torch.load(source_path, map_location="cpu", weights_only=False)
    source_cfg = dict(checkpoint["config"])
    if source_cfg["architecture"] != "equivariant_set_branching":
        raise RuntimeError("source checkpoint is not equivariant C51")
    if int(source_cfg["input_dim"]) != 65:
        raise RuntimeError("source checkpoint is not the frozen v3 observation model")

    source_agent = BranchingDQNAgent(BranchingAgentConfig(**source_cfg), device="cpu")
    source_agent.online.load_state_dict(checkpoint["online_state_dict"])
    source_agent.target.load_state_dict(checkpoint["target_state_dict"])

    destination_cfg = dict(source_cfg)
    destination_cfg.update(
        input_dim=72,
        architecture="workload_equivariant_set_branching",
        state_schema=STEP3_WORKLOAD_CONTEXT_SCHEMA,
        embedding_start_dim=40,
        workload_context_start=33,
        workload_context_features=7,
    )
    destination_agent = BranchingDQNAgent(
        BranchingAgentConfig(**destination_cfg), device="cpu"
    )
    warmstart_workload_conditioned(
        destination_agent.online, checkpoint["online_state_dict"]
    )
    warmstart_workload_conditioned(
        destination_agent.target, checkpoint["target_state_dict"]
    )

    generator = torch.Generator().manual_seed(20260815)
    old_state = torch.randn((3, 100, 65), generator=generator)
    workload = torch.randn((3, 100, 7), generator=generator)
    new_state = torch.cat((old_state[..., :33], workload, old_state[..., 33:]), dim=-1)
    mask = torch.rand((3, 100), generator=generator) > 0.2
    with torch.no_grad():
        old_q = source_agent.online.q_values(old_state, mask)
        new_q = destination_agent.online.q_values(new_state, mask)
        max_q_error = float((old_q - new_q).abs().max())
    if max_q_error > 2.0e-6:
        raise RuntimeError(f"warm-start exactness failed: {max_q_error}")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    metadata = {
        "status": "verified_workload_conditioned_warmstart",
        "source_checkpoint": str(source_path),
        "source_sha256": sha256(source_path),
        "workload_columns_initially_zero": True,
        "optimizer_reinitialized": True,
        "replay_reinitialized": True,
        "max_q_abs_error": max_q_error,
        "exactness_tolerance": 2.0e-6,
        "confirmation_seeds_used": False,
    }
    destination_agent.save(output_path, metadata)
    payload = {
        **metadata,
        "output_checkpoint": str(output_path),
        "output_sha256": sha256(output_path),
        "destination_config": asdict(destination_agent.cfg),
    }
    evidence_path.parent.mkdir(parents=True, exist_ok=True)
    evidence_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
