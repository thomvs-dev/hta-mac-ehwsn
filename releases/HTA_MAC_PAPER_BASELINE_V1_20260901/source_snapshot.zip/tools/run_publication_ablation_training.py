"""Launch matched HTA-MAC training ablations with bounded CPU concurrency."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def resolve(path):
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path):
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def load_contract(path: Path) -> dict:
    contract = json.loads(path.read_text(encoding="utf-8"))
    if contract.get("status") != "publication_ablation_training_v1":
        raise RuntimeError("unexpected ablation-training contract status")
    for field in (
        "initial_checkpoint", "qos_config", "risk_config", "reward_scale_config",
        "runtime_contract", "preflight_report",
    ):
        if sha256(contract[field]) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"artifact checksum mismatch: {field}")
    variants = [row["id"] for row in contract["variants"]]
    if len(variants) != len(set(variants)) or "full" not in variants:
        raise RuntimeError("ablation variants must be unique and include full")
    if int(contract["parallel_lineages"]) * int(contract["threads_per_lineage"]) > 16:
        raise RuntimeError("training CPU contract exceeds 16 logical threads")
    if len(set(contract["optimizer_seeds"])) < 3:
        raise RuntimeError("at least three independent optimizer seeds are required")
    return contract


def command_for(contract: dict, variant: dict, seed: int, *, smoke: bool) -> tuple[list[str], str]:
    suffix = "_smoke" if smoke else ""
    run_name = f"publication_ablation_{variant['id']}_opt{seed}{suffix}"
    command = [
        sys.executable, "-B", "experiments/train_step3_v3_complete.py",
        "--ch-risk-config", contract["risk_config"],
        "--step3-qos-config", contract["qos_config"],
        "--runtime-contract", contract["runtime_contract"],
        "--preflight-report", contract["preflight_report"],
        "--episodes", str(1 if smoke else contract["episodes"]),
        "--max-steps", str(5 if smoke else contract["max_steps"]),
        "--development-seeds", ",".join(map(str, contract["development_seeds"])),
        "--optimizer-seed", str(seed), "--run-name", run_name,
        "--device", "cpu", "--learn-every", str(contract["learn_every"]),
        "--initial-checkpoint", contract["initial_checkpoint"],
        "--reward-scale-config", contract["reward_scale_config"],
        "--reinitialize-categorical-outputs",
        "--projection-budget", str(contract["projection_budget"]),
        "--architecture", contract["architecture"],
        "--stability-interval", "25", "--stability-tail-episodes", "50",
        "--learning-rate", str(contract["learning_rate"]),
        "--normalize-input-blocks",
        "--trajectory-loss-weight", str(variant["trajectory_loss_weight"]),
        "--concavity-loss-weight", str(variant["concavity_loss_weight"]),
        "--precision", contract["precision"],
    ]
    if variant.get("ablated_feature_indices"):
        command.extend(["--ablated-feature-indices", variant["ablated_feature_indices"]])
    return command, run_name


def run_one(contract: dict, variant: dict, seed: int, smoke: bool) -> dict:
    command, run_name = command_for(contract, variant, seed, smoke=smoke)
    log_dir = ROOT / "outputs" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = log_dir / f"{run_name}.stdout.log"
    stderr_path = log_dir / f"{run_name}.stderr.log"
    environment = os.environ.copy()
    threads = str(contract["threads_per_lineage"])
    environment.update({
        "OMP_NUM_THREADS": threads, "MKL_NUM_THREADS": threads,
        "OPENBLAS_NUM_THREADS": threads, "NUMEXPR_NUM_THREADS": threads,
    })
    started = time.perf_counter()
    with stdout_path.open("w", encoding="utf-8") as stdout, stderr_path.open("w", encoding="utf-8") as stderr:
        process = subprocess.run(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
    return {
        "variant": variant["id"], "optimizer_seed": int(seed), "run_name": run_name,
        "returncode": int(process.returncode), "elapsed_seconds": time.perf_counter() - started,
        "stdout": str(stdout_path.relative_to(ROOT)), "stderr": str(stderr_path.relative_to(ROOT)),
        "run_dir": f"outputs/phase2/{run_name}", "command": command,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    contract_path = resolve(args.contract)
    output_path = resolve(args.output)
    contract = load_contract(contract_path)
    jobs = [
        (variant, int(seed))
        for variant in contract["variants"]
        for seed in contract["optimizer_seeds"]
    ]
    started = time.perf_counter()
    if args.dry_run:
        rows = [
            {
                "variant": variant["id"], "optimizer_seed": seed,
                "command": command_for(contract, variant, seed, smoke=bool(args.smoke))[0],
            }
            for variant, seed in jobs
        ]
    else:
        rows = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=int(contract["parallel_lineages"])) as pool:
            futures = [pool.submit(run_one, contract, variant, seed, bool(args.smoke)) for variant, seed in jobs]
            for future in concurrent.futures.as_completed(futures):
                row = future.result()
                rows.append(row)
                print(
                    f"ABLATION_TRAINING_COMPLETE={row['variant']}:{row['optimizer_seed']} "
                    f"RETURN={row['returncode']}", flush=True,
                )
        rows.sort(key=lambda row: (row["variant"], row["optimizer_seed"]))
    payload = {
        "schema_version": 1,
        "status": "publication_ablation_dry_run" if args.dry_run else "publication_ablation_smoke_complete" if args.smoke else "publication_ablation_training_complete",
        "contract": str(contract_path), "contract_sha256": sha256(contract_path),
        "launcher_sha256": sha256(Path(__file__)), "smoke": bool(args.smoke),
        "dry_run": bool(args.dry_run), "lineages": rows,
        "all_processes_completed": bool(args.dry_run or all(row["returncode"] in (0, 3) for row in rows)),
        "all_training_gates_passed": bool(not args.dry_run and all(row["returncode"] == 0 for row in rows)),
        "elapsed_seconds": time.perf_counter() - started,
        "selection_performed": False, "claim_boundary": contract["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": payload["status"], "lineages": len(rows), "output": str(output_path)}, indent=2))
    return 0 if payload["all_processes_completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
