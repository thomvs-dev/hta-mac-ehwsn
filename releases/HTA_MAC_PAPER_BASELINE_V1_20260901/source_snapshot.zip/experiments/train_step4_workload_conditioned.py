"""Train the workload-conditioned C51 policy on a frozen mixed scenario set."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import agents.reward_model as reward_module
import experiments.train_phase2_dynamic_curriculum as trainer
import experiments.train_step3_v3 as v3
import torch
from agents.branching_dqn import BranchingDQNAgent
from agents.ch_depletion_risk import validate_ch_risk_config
from agents.qos_constraints_v3 import Step3QoSConstraintConfig, Step3QoSConstraintController
from envs.step3_lifetime_env import configure_step3_risk
from envs.step3_policy_observation import STEP3_WORKLOAD_CONTEXT_SCHEMA
from experiments.evaluate_step4_publication_evidence import build_transfer_environments


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resolve(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else ROOT / path


class WorkloadAdapterOnlyAgent(BranchingDQNAgent):
    """Freeze the source policy and optimize only the new workload columns."""

    def __init__(self, config, device="cpu"):
        super().__init__(config, device=device)
        if config.architecture != "workload_equivariant_set_branching":
            raise RuntimeError("adapter-only training requires the workload architecture")
        for parameter in self.online.parameters():
            parameter.requires_grad_(False)
        weight = self.online.global_context[0].weight
        weight.requires_grad_(True)
        gradient_mask = torch.zeros_like(weight)
        gradient_mask[:, -config.workload_context_features:] = 1.0
        weight.register_hook(lambda gradient: gradient * gradient_mask)
        self.optimizer = torch.optim.Adam([weight], lr=config.learning_rate)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", default="config/step4_workload_conditioned_training_v1.json")
    parser.add_argument("--optimizer-seed", type=int, required=True)
    parser.add_argument("--run-name", required=True)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--episodes", type=int)
    args = parser.parse_args()

    contract_path = resolve(args.contract)
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    if contract["status"] != "frozen_before_workload_conditioned_development_training":
        raise RuntimeError("training contract is not frozen")
    if args.optimizer_seed not in contract["optimizer_seeds"]:
        raise RuntimeError("optimizer seed is outside the frozen contract")
    if set(contract["development_seeds"]) & set(contract["sealed_confirmation_seeds"]):
        raise RuntimeError("development and confirmation seeds overlap")
    warmstart = resolve(contract["warmstart"])
    if sha256(warmstart) != contract["warmstart_sha256"]:
        raise RuntimeError("warm-start checksum mismatch")

    risk_path = resolve(contract["risk_config"])
    qos_path = resolve(contract["qos_config"])
    risk = validate_ch_risk_config(json.loads(risk_path.read_text()))
    qos = Step3QoSConstraintConfig.from_payload(json.loads(qos_path.read_text()))
    configure_step3_risk(risk)
    v3._RISK_CONFIG = risk
    v3._QOS_CONFIG = qos

    def mixed_curriculum(seeds, max_steps, observation_schema, environment_profile=None):
        if list(seeds) != list(contract["development_seeds"]):
            raise RuntimeError("trainer development seeds differ from contract")
        build_contract = dict(contract)
        build_contract["horizon"] = int(max_steps)
        build_contract["budget"] = int(contract["projection_budget"])
        build_contract["risk_config"] = contract["risk_config"]
        build_contract["observation_schema"] = STEP3_WORKLOAD_CONTEXT_SCHEMA
        environments = []
        manifest = []
        for scenario in contract["training_scenarios"]:
            scenario_envs = build_transfer_environments(build_contract, scenario)
            for env in scenario_envs:
                env.step4_scenario_id = scenario["id"]
            environments.extend(scenario_envs)
            manifest.extend({
                "seed": int(env.seed),
                "target_rank": int(env.target_rank),
                "scenario_id": scenario["id"],
                "input_dim": int(env.observation_layout["total_features"]),
                "schedule_schema_version": "independent_balanced_rotation_v1",
            } for env in scenario_envs)
        if not environments:
            raise RuntimeError("mixed curriculum is empty")
        return environments, manifest, environments[0].base.cfg

    trainer.build_curriculum = mixed_curriculum
    trainer.PHASE2D_POLICY_SCHEMA = STEP3_WORKLOAD_CONTEXT_SCHEMA
    trainer.TERM_ORDER = tuple(reward_module.TERM_ORDER) + ("ch_depletion_risk",)
    trainer.RewardModel = v3.Step3V3RewardModel
    trainer.QoSConstraintConfig = Step3QoSConstraintConfig
    trainer.QoSConstraintController = Step3QoSConstraintController
    trainer.greedy_curriculum_evaluation = v3.v3_greedy_evaluation
    if contract.get("trainable_scope") == "workload_adapter_columns_only":
        trainer.BranchingDQNAgent = WorkloadAdapterOnlyAgent

    episodes = int(args.episodes or contract["episodes"])
    trainer_args = [
        sys.argv[0], "--episodes", str(episodes),
        "--max-steps", str(contract["max_steps"]),
        "--development-seeds", ",".join(map(str, contract["development_seeds"])),
        "--optimizer-seed", str(args.optimizer_seed),
        "--run-name", args.run_name,
        "--device", args.device,
        "--architecture", contract["architecture"],
        "--projection-budget", str(contract["projection_budget"]),
        "--learning-rate", str(contract["learning_rate"]),
        "--learn-every", str(contract["learn_every"]),
        "--trajectory-loss-weight", str(contract["trajectory_loss_weight"]),
        "--concavity-loss-weight", str(contract["concavity_loss_weight"]),
        "--initial-checkpoint", str(warmstart),
        "--reward-scale-config", str(resolve(contract["reward_scale_config"])),
        "--qos-constraint-config", str(qos_path),
        "--normalize-input-blocks",
        "--precision", "fp32",
        "--stability-interval", str(max(10, episodes // 3)),
        "--stability-tail-episodes", str(episodes),
    ]
    sys.argv = trainer_args
    result = trainer.main()
    run_dir = ROOT / "outputs" / "phase2" / args.run_name
    summary_path = run_dir / "summary.json"
    if summary_path.is_file():
        summary = json.loads(summary_path.read_text())
        seen = sorted({row.get("scenario_id") for row in summary.get("curriculum_clusters", [])})
        summary["step4_workload_conditioned"] = {
            "contract": str(contract_path),
            "contract_sha256": sha256(contract_path),
            "observation_schema": STEP3_WORKLOAD_CONTEXT_SCHEMA,
            "training_scenarios": seen,
            "trainable_scope": contract.get("trainable_scope", "full_network"),
            "confirmation_seeds_opened": False,
            "claim_boundary": contract["claim_boundary"],
        }
        summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    return result


if __name__ == "__main__":
    raise SystemExit(main())
