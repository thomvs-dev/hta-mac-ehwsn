"""Parallel no-learning QoS-capacity calibration for the primary profile."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.ch_depletion_risk import validate_ch_risk_config
from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from experiments.diagnose_step3_delivery_feasibility import (
    build_environments,
    evaluate_policy,
)


def resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path: str | Path) -> str:
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def load_contract(path: Path) -> dict:
    contract = json.loads(path.read_text())
    if contract.get("status") != "frozen_before_primary_oracle_calibration":
        raise RuntimeError("primary oracle contract is not frozen")
    for field in ("risk_config", "qos_template", "primary_base_config", "primary_phase1_config", "frozen_assets_manifest"):
        if sha256(contract[field]) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"artifact hash mismatch: {field}")
    if set(contract["development_seeds"]).intersection(contract["prohibited_seeds"]):
        raise RuntimeError("prohibited seed requested")
    return contract


def worker(contract_path_string, seed):
    contract = load_contract(resolve(contract_path_string))
    torch.set_num_threads(int(contract["threads_per_worker"]))
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    risk = validate_ch_risk_config(json.loads(resolve(contract["risk_config"]).read_text()))
    qos = Step3QoSConstraintConfig.from_payload(
        json.loads(resolve(contract["qos_template"]).read_text())
    )
    environments, manifest, cfg = build_environments(
        None, risk, int(contract["horizon"]), seeds=(int(seed),)
    )
    if int(cfg.frame_slot_budget) != int(contract["budget"]):
        raise RuntimeError("primary budget changed")
    rows = evaluate_policy(
        "fair_budget_fill_oracle", environments, None, qos, int(contract["budget"])
    )
    return int(seed), rows, manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path, output_path = resolve(args.contract), resolve(args.output)
    contract = load_contract(contract_path)
    started = time.perf_counter()
    rows, manifests = [], {}
    with concurrent.futures.ProcessPoolExecutor(max_workers=int(contract["workers"])) as pool:
        futures = [pool.submit(worker, str(contract_path), seed) for seed in contract["development_seeds"]]
        for future in concurrent.futures.as_completed(futures):
            seed, local_rows, manifest = future.result()
            rows.extend(local_rows)
            manifests[str(seed)] = manifest
            print(f"SEED_COMPLETE={seed}", flush=True)
    rows.sort(key=lambda row: (row["seed"], row["target_rank"]))
    values = np.asarray([row["delivery_ratio"] for row in rows], dtype=np.float64)
    q10 = float(np.percentile(values, 10))
    floor = math.floor((0.90 * q10) / 0.005) * 0.005
    passes = int(np.sum(values >= floor))
    required = int(math.ceil(float(contract["minimum_oracle_delivery_pass_fraction"]) * len(rows)))
    stale_passes = int(sum(row["stale_ratio"] <= float(contract["maximum_stale_ratio"]) for row in rows))
    fairness_passes = int(sum(row["episode_service_fairness"] >= float(contract["minimum_episode_service_fairness"]) for row in rows))
    feasible = passes >= required and stale_passes >= required and fairness_passes >= required
    payload = {
        "schema_version": 1,
        "status": "primary_qos_candidate_authorized" if feasible else "primary_qos_not_feasible_stop_training",
        "contract_sha256": sha256(contract_path),
        "evaluator_sha256": sha256(Path(__file__)),
        "development_only": True,
        "no_learning": True,
        "seeds": contract["development_seeds"],
        "pairs": len(rows),
        "oracle_delivery_distribution": {
            "minimum": float(values.min()), "q10": q10,
            "median": float(np.median(values)), "mean": float(values.mean()),
            "maximum": float(values.max()),
        },
        "selected_delivery_floor": float(floor),
        "delivery_floor_rule": contract["delivery_floor_rule"],
        "delivery_passes": passes,
        "stale_passes": stale_passes,
        "fairness_passes": fairness_passes,
        "required_passes": required,
        "training_candidate_authorized": bool(feasible),
        "rows": rows,
        "manifests": manifests,
        "elapsed_seconds": time.perf_counter() - started,
        "remaining_confirmation_seeds_opened": False,
        "claim_boundary": contract["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({key: payload[key] for key in (
        "status", "pairs", "oracle_delivery_distribution", "selected_delivery_floor",
        "delivery_passes", "stale_passes", "fairness_passes", "required_passes",
    )}, indent=2), flush=True)
    print(f"OUTPUT={output_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
