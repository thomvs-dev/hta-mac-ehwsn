"""Evaluate matched retrained ablations with training lineage as the unit."""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.evaluate_publication_ablation_and_all_cluster import (
    evaluate_trial,
    load_contract as load_evaluation_contract,
    paired_summary,
    resolve,
    sha256,
)
from tools.run_publication_ablation_training import load_contract as load_training_contract


def checkpoint_for(row: dict) -> Path:
    path = resolve(Path(row["run_dir"]) / "branching_c51.pt")
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def validate_lineages(training_contract: dict, manifest: dict, *, smoke: bool) -> list[dict]:
    expected = {
        (variant["id"], int(seed))
        for variant in training_contract["variants"]
        for seed in training_contract["optimizer_seeds"]
    }
    rows = list(manifest["lineages"])
    actual = {(row["variant"], int(row["optimizer_seed"])) for row in rows}
    if actual != expected:
        raise RuntimeError("training lineage matrix is incomplete")
    for row in rows:
        checkpoint = checkpoint_for(row)
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        config = payload["config"]
        variant = next(item for item in training_contract["variants"] if item["id"] == row["variant"])
        expected_features = tuple(
            int(value) for value in variant["ablated_feature_indices"].split(",") if value
        )
        if tuple(config.get("ablated_feature_indices", ())) != expected_features:
            raise RuntimeError(f"feature-ablation mismatch: {row['run_name']}")
        if float(config["trajectory_loss_weight"]) != float(variant["trajectory_loss_weight"]):
            raise RuntimeError(f"trajectory-loss mismatch: {row['run_name']}")
        if float(config["concavity_loss_weight"]) != float(variant["concavity_loss_weight"]):
            raise RuntimeError(f"concavity-loss mismatch: {row['run_name']}")
        if not smoke and int(payload.get("metadata", {}).get("episodes_completed", 0)) != int(training_contract["episodes"]):
            raise RuntimeError(f"full training incomplete: {row['run_name']}")
        row = dict(row)
        row["checkpoint"] = str(checkpoint)
        row["checkpoint_sha256"] = sha256(checkpoint)
    return [
        {**row, "checkpoint": str(checkpoint_for(row)), "checkpoint_sha256": sha256(checkpoint_for(row))}
        for row in rows
    ]


def analyze(raw: dict, lineages: list[dict], scenarios: list[dict], evaluation_seeds: list[int], bootstrap_seed: int):
    metrics = (
        "delivery_ratio", "stale_ratio", "service_fairness", "fnd_round",
        "hnd_round", "lnd_round", "packets_per_j", "network_energy_j",
        "jain_weighted_goodput_per_j", "residual_energy_fairness",
    )
    optimizer_seeds = sorted({int(row["optimizer_seed"]) for row in lineages})
    variants = sorted({row["variant"] for row in lineages})
    rng = np.random.default_rng(int(bootstrap_seed))
    result = {}
    for scenario in scenarios:
        scenario_id = scenario["id"]
        result[scenario_id] = {"variants": {}, "full_minus_variant": {}}
        lineage_means = {variant: {} for variant in variants}
        for variant in variants:
            for optimizer_seed in optimizer_seeds:
                key = f"{variant}:{optimizer_seed}"
                rows = [raw[scenario_id][key][str(seed)] for seed in evaluation_seeds]
                lineage_means[variant][optimizer_seed] = {
                    metric: float(np.mean([row[metric] for row in rows])) for metric in metrics
                }
            result[scenario_id]["variants"][variant] = {
                f"mean_{metric}": float(np.mean([
                    lineage_means[variant][seed][metric] for seed in optimizer_seeds
                ])) for metric in metrics
            }
        for variant in variants:
            if variant == "full":
                continue
            result[scenario_id]["full_minus_variant"][variant] = {
                metric: paired_summary(np.asarray([
                    lineage_means["full"][seed][metric] - lineage_means[variant][seed][metric]
                    for seed in optimizer_seeds
                ]), rng, 10000)
                for metric in metrics
            }
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--training-contract", type=Path, required=True)
    parser.add_argument("--training-manifest", type=Path, required=True)
    parser.add_argument("--evaluation-contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--pilot", action="store_true")
    args = parser.parse_args()
    if args.smoke and args.pilot:
        parser.error("--smoke and --pilot are mutually exclusive")
    training_contract_path = resolve(args.training_contract)
    training_manifest_path = resolve(args.training_manifest)
    evaluation_contract_path = resolve(args.evaluation_contract)
    training_contract = load_training_contract(training_contract_path)
    evaluation_contract = load_evaluation_contract(evaluation_contract_path)
    manifest = json.loads(training_manifest_path.read_text(encoding="utf-8"))
    lineages = validate_lineages(training_contract, manifest, smoke=bool(args.smoke))
    if args.smoke:
        evaluation_seeds = [evaluation_contract["smoke_seed"]]
    elif args.pilot:
        evaluation_seeds = evaluation_contract["pilot_seeds"]
    else:
        evaluation_seeds = evaluation_contract["evaluation_seeds"]
    scenarios = evaluation_contract["scenarios"][:2] if args.smoke else [
        row for row in evaluation_contract["scenarios"]
        if row["id"] in (
            {"reference_100", "traffic_high"} if args.pilot else
            {"reference_100", "nodes_20", "traffic_high", "harvest_low", "harvest_high"}
        )
    ]
    raw = {
        scenario["id"]: {
            f"{row['variant']}:{row['optimizer_seed']}": {} for row in lineages
        } for scenario in scenarios
    }
    jobs = [
        (scenario, lineage, int(seed))
        for scenario in scenarios for lineage in lineages for seed in evaluation_seeds
    ]
    if args.smoke:
        completed = []
        for index, (scenario, lineage, seed) in enumerate(jobs, start=1):
            completed.append(evaluate_trial(
                str(evaluation_contract_path), scenario, "hta_mac", seed, True,
                lineage["checkpoint"],
            ) + (lineage,))
            print(f"TRAINED_ABLATION_PROGRESS={index}/{len(jobs)}", flush=True)
    else:
        completed = []
        with concurrent.futures.ProcessPoolExecutor(max_workers=int(evaluation_contract["workers"])) as pool:
            futures = [
                (pool.submit(
                    evaluate_trial, str(evaluation_contract_path), scenario,
                    "hta_mac", seed, False, lineage["checkpoint"],
                ), lineage)
                for scenario, lineage, seed in jobs
            ]
            for index, (future, lineage) in enumerate(futures, start=1):
                completed.append(future.result() + (lineage,))
                print(f"TRAINED_ABLATION_PROGRESS={index}/{len(futures)}", flush=True)
    for scenario, _, seed, row, lineage in completed:
        key = f"{lineage['variant']}:{lineage['optimizer_seed']}"
        raw[scenario][key][str(seed)] = row
    checks = {
        "complete_lineage_matrix": len(lineages) == len(training_contract["variants"]) * len(training_contract["optimizer_seeds"]),
        "all_evaluations_complete": all(
            set(rows) == set(map(str, evaluation_seeds))
            for scenario in raw.values() for rows in scenario.values()
        ),
        "zero_feasibility_violations": all(
            row["feasibility_violations"] == 0
            for scenario in raw.values() for lineage in scenario.values() for row in lineage.values()
        ),
    }
    payload = {
        "schema_version": 1,
        "status": (
            "trained_ablation_smoke_complete" if args.smoke else
            "trained_ablation_development_pilot_complete" if args.pilot else
            "trained_ablation_evaluation_complete"
        ),
        "smoke": bool(args.smoke), "development_pilot": bool(args.pilot), "checks": checks,
        "training_gates_passed": bool(manifest.get("all_training_gates_passed", False)),
        "training_contract_sha256": sha256(training_contract_path),
        "training_manifest_sha256": sha256(training_manifest_path),
        "evaluation_contract_sha256": sha256(evaluation_contract_path),
        "lineages": lineages, "evaluation_seeds": evaluation_seeds,
        "scenarios": [row["id"] for row in scenarios], "raw": raw,
        "analysis": {} if args.smoke else analyze(
            raw, lineages, scenarios, evaluation_seeds, evaluation_contract["bootstrap_seed"]
        ),
        "claim_boundary": (
            "development-only diagnostic on gate-unqualified checkpoints; final evaluation cohort remains sealed"
            if args.pilot else
            "training-lineage-level ablation inference; no best-lineage selection"
        ),
    }
    if not all(checks.values()):
        payload["status"] = "trained_ablation_incomplete"
    output_path = resolve(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": payload["status"], "checks": checks, "output": str(output_path)}, indent=2))
    return 0 if all(checks.values()) else 3


if __name__ == "__main__":
    raise SystemExit(main())
