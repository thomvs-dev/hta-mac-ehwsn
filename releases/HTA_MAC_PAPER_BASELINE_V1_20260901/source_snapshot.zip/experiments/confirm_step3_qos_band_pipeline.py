"""Distill and evaluate the frozen QoS-band method on one reserved seed."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import experiments.train_phase2_dynamic_curriculum as trainer
from agents.ch_depletion_risk import validate_ch_risk_config
from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from envs.step3_policy_observation import STEP3_CH_CONTEXT_SCHEMA
from experiments.diagnose_step3_delivery_feasibility import (
    aggregate,
    build_environments,
    evaluate_policy,
    load_agent,
    sha256,
)
from experiments.distill_step3_qos_shield import (
    agreement,
    collect_intervention_demonstrations,
    set_cpu_contract,
    train_distillation,
)
from experiments.sweep_step3_qos_band_projection import qos_band_projection


def resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def load_contract(path: Path) -> dict:
    contract = json.loads(path.read_text())
    if contract.get("status") != "frozen_before_reserved_confirmation":
        raise RuntimeError("confirmation contract is not frozen")
    for field in (
        "base_controller_config", "band_config", "risk_config", "qos_config",
        "environment_profile", "runtime_contract", "preflight_report",
        "reward_scale_config",
    ):
        artifact = resolve(contract[field])
        if sha256(artifact) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"confirmation artifact hash mismatch: {field}")
    seed = int(contract["confirmation_seed"])
    if seed in set(contract["prohibited_registered_held_out_seeds"]):
        raise RuntimeError("confirmation seed overlaps the registered held-out cohort")
    return contract


def evaluate_band(agent, environments, qos, budget, band, horizon):
    rows = []
    totals = {
        "added_slots": 0, "removed_slots": 0,
        "risk_blocked_slots": 0, "upper_excess_before_removal": 0,
    }
    for env in environments:
        observation, mask, _ = env.reset()
        done = False
        while not done:
            padded, padded_mask, caps = trainer.padded_state(
                env, observation, mask, env.base.n_nodes
            )
            base_action, q_values = agent.act(
                padded, padded_mask, epsilon=0.0, caps=caps, budget=budget,
                tie_break_priorities=np.arange(env.base.n_nodes),
            )
            action, audit = qos_band_projection(
                base_action, q_values, caps, padded_mask, env,
                lower_target=float(band["lower_delivery_target"]),
                upper_target=float(band["upper_delivery_target"]),
                reserve_floor=float(band["reserve_floor"]),
                completion_fraction=float(band["completion_fraction"]),
            )
            totals["added_slots"] += int(audit["added"])
            totals["removed_slots"] += int(audit["removed"])
            totals["risk_blocked_slots"] += int(audit["risk_blocked"])
            totals["upper_excess_before_removal"] += int(audit["upper_excess_before_removal"])
            observation, mask, done, _ = env.step(action)
        counts = env.step3_qos_counts
        demand = max(1, int(counts["demand"]))
        delivery = int(counts["delivered"]) / demand
        stale = int(counts["stale"]) / demand
        fairness = float(counts["fairness"])
        rows.append({
            "seed": int(env.seed),
            "target_rank": int(env.target_rank),
            "delivery_ratio": delivery,
            "stale_ratio": stale,
            "fairness": fairness,
            "delivery_pass": bool(delivery >= qos.minimum_delivery_ratio),
            "stale_pass": bool(stale <= qos.maximum_stale_drop_ratio),
            "fairness_pass": bool(fairness >= qos.minimum_queue_fairness),
            "joint_qos_pass": bool(
                delivery >= qos.minimum_delivery_ratio
                and stale <= qos.maximum_stale_drop_ratio
                and fairness >= qos.minimum_queue_fairness
            ),
            "fnd_free_steps": int(
                env.base.t_fnd if env.base.t_fnd is not None else horizon
            ),
        })
    return {
        "pairs": len(rows),
        "joint_qos_pass_count": int(sum(row["joint_qos_pass"] for row in rows)),
        "delivery_pass_count": int(sum(row["delivery_pass"] for row in rows)),
        "stale_pass_count": int(sum(row["stale_pass"] for row in rows)),
        "fairness_pass_count": int(sum(row["fairness_pass"] for row in rows)),
        "mean_delivery_ratio": float(np.mean([row["delivery_ratio"] for row in rows])),
        "mean_stale_ratio": float(np.mean([row["stale_ratio"] for row in rows])),
        "mean_fairness": float(np.mean([row["fairness"] for row in rows])),
        "mean_fnd_free_steps": float(np.mean([row["fnd_free_steps"] for row in rows])),
        "totals": totals,
        "rows": rows,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--confirmation-contract", type=Path, required=True)
    parser.add_argument("--base-checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--cpu-threads", type=int, required=True)
    args = parser.parse_args()
    contract_path = resolve(args.confirmation_contract)
    checkpoint_path = resolve(args.base_checkpoint)
    output_dir = resolve(args.output_dir)
    contract = load_contract(contract_path)
    if args.cpu_threads != int(contract["cpu_threads"]):
        raise RuntimeError("confirmation CPU-thread contract changed")
    seed = int(contract["confirmation_seed"])
    distill_seed = int(contract["distillation_optimizer_seed"])
    horizon = int(contract["horizon"])
    set_cpu_contract(args.cpu_threads, distill_seed)
    output_dir.mkdir(parents=True, exist_ok=True)
    controller_path = resolve(contract["base_controller_config"])
    band_path = resolve(contract["band_config"])
    risk_path = resolve(contract["risk_config"])
    qos_path = resolve(contract["qos_config"])
    profile_path = resolve(contract["environment_profile"])
    controller = json.loads(controller_path.read_text())
    band = json.loads(band_path.read_text())
    risk = validate_ch_risk_config(json.loads(risk_path.read_text()))
    qos = Step3QoSConstraintConfig.from_payload(json.loads(qos_path.read_text()))
    agent, source = load_agent(checkpoint_path)
    if agent.cfg.state_schema != STEP3_CH_CONTEXT_SCHEMA or agent.cfg.budget != int(contract["budget"]):
        raise RuntimeError("base checkpoint violates the frozen Step 3 B16 contract")
    metadata = source.get("metadata", {})
    if int(metadata.get("episode", -1)) != int(contract["episodes"]):
        raise RuntimeError("base checkpoint is not the frozen episode-100 artifact")

    started = time.perf_counter()
    environments, manifest, cfg = build_environments(
        profile_path, risk, horizon, seeds=(seed,)
    )
    states, actions, masks, caps, collection = collect_intervention_demonstrations(
        agent, environments, cfg.frame_slot_budget, controller
    )
    parameters = contract["distillation"]
    before = agreement(
        agent, states, actions, masks, caps, cfg.frame_slot_budget,
        int(parameters["batch_size"]),
    )
    history, train_idx, validation_idx = train_distillation(
        agent, (states, actions, masks, caps),
        epochs=int(parameters["epochs"]),
        batch_size=int(parameters["batch_size"]),
        learning_rate=float(parameters["learning_rate"]),
        margin=float(parameters["margin"]),
        seed=distill_seed,
    )
    distilled_checkpoint = output_dir / "branching_c51_shield_distilled_confirmation.pt"
    agent.save(distilled_checkpoint, {
        "method": "frozen_dqfd_style_shield_distillation_confirmation",
        "episode": int(contract["episodes"]),
        "confirmation_seed": seed,
        "base_optimizer_seed": int(contract["base_optimizer_seed"]),
        "distillation_optimizer_seed": distill_seed,
        "source_checkpoint_sha256": sha256(checkpoint_path),
        "confirmation_contract_sha256": sha256(contract_path),
    })

    raw_envs, _, _ = build_environments(profile_path, risk, horizon, seeds=(seed,))
    raw_rows = evaluate_policy(
        "trained_greedy", raw_envs, agent, qos, cfg.frame_slot_budget
    )
    band_envs, _, _ = build_environments(profile_path, risk, horizon, seeds=(seed,))
    band_result = evaluate_band(
        agent, band_envs, qos, cfg.frame_slot_budget, band, horizon
    )
    gates = contract["confirmation_gates"]
    checks = {
        "joint_qos": band_result["joint_qos_pass_count"] >= int(gates["required_joint_qos_pairs"]),
        "delivery": band_result["delivery_pass_count"] >= int(gates["required_delivery_pairs"]),
        "fnd": band_result["mean_fnd_free_steps"] >= float(gates["minimum_mean_fnd_free_steps"]),
    }
    passed = all(checks.values())
    payload = {
        "schema_version": 1,
        "status": "frozen_single_seed_confirmation_pass" if passed else "frozen_single_seed_confirmation_fail_stop_no_retuning",
        "confirmation_pass": passed,
        "checks": checks,
        "gates": gates,
        "confirmation_seed": seed,
        "target_ranks": list(range(len(manifest))),
        "base_optimizer_seed": int(contract["base_optimizer_seed"]),
        "distillation_optimizer_seed": distill_seed,
        "contract_sha256": sha256(contract_path),
        "base_checkpoint_sha256": sha256(checkpoint_path),
        "distilled_checkpoint_sha256": sha256(distilled_checkpoint),
        "distillation_parameters": parameters,
        "demonstration_collection": collection,
        "demonstrations": int(len(states)),
        "baseline_demonstration_agreement": before,
        "history": history,
        "raw_distilled_policy": aggregate(raw_rows, qos),
        "frozen_qos_band": band_result,
        "elapsed_seconds": time.perf_counter() - started,
        "selection_or_retuning_performed": False,
        "remaining_reserved_confirmation_seeds": contract["remaining_reserved_confirmation_seeds"],
        "publication_evidence": False,
        "claim_boundary": contract["claim_boundary"],
    }
    report = output_dir / "STEP3_QOS_BAND_CONFIRMATION_REPORT.json"
    report.write_text(json.dumps(payload, indent=2) + "\n")
    print(f"CONFIRMATION_STATUS={payload['status']}", flush=True)
    print(f"JOINT_QOS={band_result['joint_qos_pass_count']}/{band_result['pairs']}", flush=True)
    print(f"DELIVERY={band_result['delivery_pass_count']}/{band_result['pairs']}", flush=True)
    print(f"MEAN_FND={band_result['mean_fnd_free_steps']:.4f}", flush=True)
    print(f"REPORT={report}", flush=True)
    return 0 if passed else 3


if __name__ == "__main__":
    raise SystemExit(main())
