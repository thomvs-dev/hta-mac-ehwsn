"""Frozen seed-3400 matched diagnostic for the final QoS-band checkpoint."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import experiments.train_phase2_dynamic_curriculum as trainer
from agents.budget_projection import project_slot_budget
from agents.ch_depletion_risk import validate_ch_risk_config
from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from baselines.policies import _rank_proportional
from experiments.diagnose_step3_delivery_feasibility import build_environments, load_agent
from experiments.sweep_step3_qos_band_projection import qos_band_projection


def resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path: str | Path) -> str:
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def load_contract(path: Path) -> dict:
    contract = json.loads(path.read_text())
    if contract.get("status") != "frozen_before_matched_baseline_diagnostic":
        raise RuntimeError("matched diagnostic contract is not frozen")
    for field in ("hta_checkpoint", "band_config", "environment_profile", "risk_config", "qos_config"):
        if sha256(contract[field]) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"matched diagnostic artifact hash mismatch: {field}")
    if contract["policies"] != ["hta_mac_qos_band", "energy_proportional", "s2a2mac_adapted"]:
        raise RuntimeError("matched diagnostic policy set changed")
    return contract


def energy_proportional_action(env, mask, budget, exponent):
    action = np.zeros(env.base.n_nodes, dtype=np.int64)
    members = np.flatnonzero(np.asarray(mask, dtype=bool))
    if len(members):
        scores = np.power(
            env.base.energy[members] / env.base.cfg.initial_energy_j,
            float(exponent),
        )
        action[members] = _rank_proportional(
            scores, budget, env.base.cfg.n_max
        )
    return action


def s2a2mac_action(env, mask, budget, energy_weight):
    action = np.zeros(env.base.n_nodes, dtype=np.int64)
    if (int(env.target_cluster) + int(env.base.round)) % 2 == 0:
        return action
    members = np.flatnonzero(np.asarray(mask, dtype=bool))
    if not len(members):
        return action
    energy = np.clip(
        env.base.energy[members] / env.base.cfg.initial_energy_j, 0.0, 1.0
    )
    load = np.clip(
        env.base.queue[members] / env.base.cfg.queue_max_packets, 0.0, 1.0
    )
    score = float(energy_weight) * energy + (1.0 - float(energy_weight)) * load
    order = np.argsort(score, kind="stable")
    layers = np.ones(len(members), dtype=np.int64)
    first, second = len(members) // 3, (2 * len(members)) // 3
    layers[order[first:second]] = 2
    layers[order[second:]] = 3
    q_values = np.zeros((len(members), env.base.cfg.n_max + 1))
    for local, desired in enumerate(layers):
        q_values[local, : desired + 1] = np.arange(desired + 1)
        if desired < env.base.cfg.n_max:
            q_values[local, desired + 1:] = desired - 1.0
    action[members] = project_slot_budget(
        q_values, budget, stop_at_nonpositive_gain=True
    )
    return action


def evaluate(policy_name, environments, agent, qos, band, contract):
    rows = []
    budget = int(contract["budget"])
    horizon = int(contract["horizon"])
    params = contract["baseline_parameters"]
    for env in environments:
        observation, mask, _ = env.reset()
        done = False
        total_energy = 0.0
        target_role_energy = 0.0
        allocated_slots = 0
        zero_action_steps = 0
        band_totals = {"added": 0, "removed": 0, "risk_blocked": 0}
        while not done:
            current_members = env.members.copy()
            current_ch = int(env.ch)
            padded, padded_mask, caps = trainer.padded_state(
                env, observation, mask, env.base.n_nodes
            )
            if policy_name == "hta_mac_qos_band":
                base_action, q_values = agent.act(
                    padded, padded_mask, epsilon=0.0, caps=caps,
                    budget=budget,
                    tie_break_priorities=np.arange(env.base.n_nodes),
                )
                action, audit = qos_band_projection(
                    base_action, q_values, caps, padded_mask, env,
                    lower_target=float(band["lower_delivery_target"]),
                    upper_target=float(band["upper_delivery_target"]),
                    reserve_floor=float(band["reserve_floor"]),
                    completion_fraction=float(band["completion_fraction"]),
                )
                band_totals["added"] += int(audit["added"])
                band_totals["removed"] += int(audit["removed"])
                band_totals["risk_blocked"] += int(audit["risk_blocked"])
            elif policy_name == "energy_proportional":
                action = energy_proportional_action(
                    env, padded_mask, budget,
                    params["energy_proportional_score_exponent"],
                )
            elif policy_name == "s2a2mac_adapted":
                action = s2a2mac_action(
                    env, padded_mask, budget,
                    params["s2a2mac_energy_weight"],
                )
            else:
                raise ValueError(policy_name)
            allocated_slots += int(action.sum())
            zero_action_steps += int(action.sum() == 0)
            observation, mask, done, info = env.step(action)
            trace = info["energy_trace"]
            total_energy += float(np.asarray(trace["consumed"]).sum())
            roles = trace["role_energy"]
            target_role_energy += float(roles["member_tx"][current_members].sum())
            target_role_energy += float(
                roles["ch_rx"][current_ch]
                + roles["ch_aggregate"][current_ch]
                + roles["ch_tx_bs"][current_ch]
            )
        counts = env.step3_qos_counts
        demand = max(1, int(counts["demand"]))
        delivery = int(counts["delivered"]) / demand
        stale = int(counts["stale"]) / demand
        prospective_fairness = float(counts["episode_service_fairness"])
        legacy_fairness = float(counts["fairness"])
        fnd = int(env.base.t_fnd if env.base.t_fnd is not None else horizon)
        target_packets = int(counts["delivered"])
        global_packets = int(env.base.total_packets)
        rows.append({
            "seed": int(env.seed),
            "target_rank": int(env.target_rank),
            "policy": policy_name,
            "rounds": int(env.base.round),
            "target_packets_delivered": target_packets,
            "target_packets_offered": int(counts["demand"]),
            "delivery_ratio": delivery,
            "stale_ratio": stale,
            "episode_service_fairness": prospective_fairness,
            "legacy_terminal_fairness": legacy_fairness,
            "delivery_pass": bool(delivery >= qos.minimum_delivery_ratio),
            "stale_pass": bool(stale <= qos.maximum_stale_drop_ratio),
            "fairness_pass": bool(prospective_fairness >= qos.minimum_queue_fairness),
            "joint_qos_pass": bool(
                delivery >= qos.minimum_delivery_ratio
                and stale <= qos.maximum_stale_drop_ratio
                and prospective_fairness >= qos.minimum_queue_fairness
            ),
            "fnd_free_steps": fnd,
            "fnd_event_observed": bool(env.base.t_fnd is not None),
            "right_censored_fnd": bool(env.base.t_fnd is None),
            "alive_at_end": int(env.base.alive.sum()),
            "global_packets_delivered": global_packets,
            "total_network_energy_j": total_energy,
            "target_role_energy_j": target_role_energy,
            "global_packets_per_j": global_packets / max(total_energy, 1e-12),
            "target_packets_per_role_j": target_packets / max(target_role_energy, 1e-12),
            "allocated_slots": allocated_slots,
            "zero_action_fraction": zero_action_steps / max(1, int(env.base.round)),
            "band_added_slots": band_totals["added"] if policy_name == "hta_mac_qos_band" else None,
            "band_removed_slots": band_totals["removed"] if policy_name == "hta_mac_qos_band" else None,
            "band_risk_blocked_slots": band_totals["risk_blocked"] if policy_name == "hta_mac_qos_band" else None,
        })
    return rows


def aggregate(rows):
    return {
        "pairs": len(rows),
        "joint_qos_pass_count": int(sum(row["joint_qos_pass"] for row in rows)),
        "delivery_pass_count": int(sum(row["delivery_pass"] for row in rows)),
        "stale_pass_count": int(sum(row["stale_pass"] for row in rows)),
        "fairness_pass_count": int(sum(row["fairness_pass"] for row in rows)),
        "fnd_events": int(sum(row["fnd_event_observed"] for row in rows)),
        **{
            f"mean_{field}": float(np.mean([row[field] for row in rows]))
            for field in (
                "delivery_ratio", "stale_ratio", "episode_service_fairness",
                "legacy_terminal_fairness", "fnd_free_steps", "alive_at_end",
                "global_packets_delivered", "total_network_energy_j",
                "target_role_energy_j", "global_packets_per_j",
                "target_packets_per_role_j", "allocated_slots", "zero_action_fraction",
            )
        },
    }


def paired_differences(rows, reference="hta_mac_qos_band"):
    indexed = {
        policy: {int(row["target_rank"]): row for row in rows if row["policy"] == policy}
        for policy in sorted({row["policy"] for row in rows})
    }
    fields = (
        "delivery_ratio", "stale_ratio", "episode_service_fairness",
        "fnd_free_steps", "global_packets_delivered", "total_network_energy_j",
        "global_packets_per_j", "target_packets_per_role_j", "allocated_slots",
    )
    result = {}
    for policy, mapping in indexed.items():
        if policy == reference:
            continue
        ranks = sorted(set(indexed[reference]).intersection(mapping))
        metrics = {}
        for field in fields:
            differences = np.asarray([
                indexed[reference][rank][field] - mapping[rank][field]
                for rank in ranks
            ], dtype=np.float64)
            metrics[field] = {
                "orientation": f"{reference}_minus_{policy}",
                "paired_ranks": len(ranks),
                "mean_difference": float(differences.mean()),
                "median_difference": float(np.median(differences)),
                "wins": int(np.sum(differences > 0.0)),
                "ties": int(np.sum(differences == 0.0)),
                "losses": int(np.sum(differences < 0.0)),
                "inferential_p_value": None,
                "note": "target ranks share one seed/model and are not independent trials",
            }
        result[policy] = metrics
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path = resolve(args.contract)
    output_path = resolve(args.output)
    contract = load_contract(contract_path)
    torch.set_num_threads(int(contract["cpu_threads"]))
    try:
        torch.set_num_interop_threads(max(1, min(4, int(contract["cpu_threads"]) // 4)))
    except RuntimeError:
        pass
    print(
        f"CPU_THREAD_CONTRACT intraop={torch.get_num_threads()} "
        f"interop={torch.get_num_interop_threads()}",
        flush=True,
    )
    risk = validate_ch_risk_config(json.loads(resolve(contract["risk_config"]).read_text()))
    qos = Step3QoSConstraintConfig.from_payload(json.loads(resolve(contract["qos_config"]).read_text()))
    band = json.loads(resolve(contract["band_config"]).read_text())
    agent, checkpoint = load_agent(resolve(contract["hta_checkpoint"]))
    if agent.cfg.budget != int(contract["budget"]):
        raise RuntimeError("checkpoint budget does not match the frozen diagnostic")
    started = time.perf_counter()
    rows = []
    for policy_name in contract["policies"]:
        environments, manifest, cfg = build_environments(
            resolve(contract["environment_profile"]), risk,
            int(contract["horizon"]), seeds=(int(contract["seed"]),),
        )
        if len(environments) != int(contract["target_ranks"]):
            raise RuntimeError("target-rank count changed")
        rows.extend(evaluate(policy_name, environments, agent, qos, band, contract))
        print(f"POLICY_COMPLETE={policy_name}", flush=True)
    aggregates = {
        policy: aggregate([row for row in rows if row["policy"] == policy])
        for policy in contract["policies"]
    }
    payload = {
        "schema_version": 1,
        "status": "matched_seed3400_diagnostic_complete",
        "contract_sha256": sha256(contract_path),
        "evaluator_sha256": sha256(Path(__file__)),
        "checkpoint_episode": checkpoint.get("metadata", {}).get("episode"),
        "checkpoint_sha256": sha256(contract["hta_checkpoint"]),
        "seed": int(contract["seed"]),
        "target_ranks_are_independent_trials": False,
        "inferential_claim_permitted": False,
        "fairness_endpoint": contract["prospective_fairness"],
        "aggregates": aggregates,
        "paired_rank_differences": paired_differences(rows),
        "rows": rows,
        "elapsed_seconds": time.perf_counter() - started,
        "selection_or_retuning_performed": False,
        "remaining_reserved_confirmation_seeds_opened": False,
        "claim_boundary": contract["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({
        "status": payload["status"],
        "aggregates": aggregates,
        "elapsed_seconds": payload["elapsed_seconds"],
        "output": str(output_path),
    }, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
