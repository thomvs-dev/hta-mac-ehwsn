"""Add preregistered fair-energy metrics to an existing all-cluster result.

This is analysis-only: it never simulates, trains, selects a checkpoint, or
changes the source result.  The output records hashes of both source evidence
and the current metric contract.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from experiments.evaluate_publication_ablation_and_all_cluster import (
    analyze,
    jain_weighted_goodput_efficiency,
    load_contract,
    resolve,
    sha256,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path = resolve(args.contract)
    source_path = resolve(args.source)
    output_path = resolve(args.output)
    contract = load_contract(contract_path)
    qos = Step3QoSConstraintConfig.from_payload(
        json.loads(resolve(contract["qos_config"]).read_text(encoding="utf-8"))
    )
    source = json.loads(source_path.read_text(encoding="utf-8"))
    if source.get("smoke") or not source.get("checks", {}).get("all_tasks_complete"):
        raise RuntimeError("source must be a complete non-smoke all-cluster result")
    raw = source["raw"]
    for scenario in raw.values():
        for policy in scenario.values():
            for row in policy.values():
                row["jain_weighted_goodput_per_j"] = jain_weighted_goodput_efficiency(
                    row["packets_per_j"], row["service_fairness"]
                )
                row["qos_joint_pass"] = bool(
                    row["delivery_ratio"] >= qos.minimum_delivery_ratio
                    and row["stale_ratio"] <= qos.maximum_stale_drop_ratio
                    and row["service_fairness"] >= qos.minimum_queue_fairness
                )
    scenarios = [
        row for row in contract["scenarios"] if row["id"] in set(source["scenarios"])
    ]
    payload = {
        "schema_version": 1,
        "status": "publication_fair_energy_reanalysis_complete",
        "source": str(source_path),
        "source_sha256": sha256(source_path),
        "contract": str(contract_path),
        "contract_sha256": sha256(contract_path),
        "seeds": list(map(int, source["seeds"])),
        "scenarios": source["scenarios"],
        "metric_definitions": contract["derived_metrics"],
        "analysis": analyze(contract, raw, list(map(int, source["seeds"])), scenarios),
        "claim_boundary": (
            "post-hoc development-pilot metric discovery; rankings are exploratory; "
            "confirmation requires the sealed 4200-4219 cohort and all standard metrics"
        ),
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": payload["status"], "output": str(output_path)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
