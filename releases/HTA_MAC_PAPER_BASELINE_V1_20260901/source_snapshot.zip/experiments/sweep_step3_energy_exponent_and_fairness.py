"""Frozen development-only energy-proportional exponent/fairness sweep."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.ch_depletion_risk import validate_ch_risk_config
from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from experiments.diagnose_step3_delivery_feasibility import build_environments
from experiments.evaluate_step3_qos_band_matched_baselines import evaluate


def resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path: str | Path) -> str:
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def distribution(values):
    values = np.asarray(values, dtype=np.float64)
    return {
        "minimum": float(np.min(values)),
        "q05": float(np.percentile(values, 5)),
        "q10": float(np.percentile(values, 10)),
        "q25": float(np.percentile(values, 25)),
        "median": float(np.median(values)),
        "mean": float(np.mean(values)),
        "q75": float(np.percentile(values, 75)),
        "q90": float(np.percentile(values, 90)),
        "q95": float(np.percentile(values, 95)),
        "maximum": float(np.max(values)),
    }


def aggregate(rows):
    return {
        "pairs": len(rows),
        "joint_qos_pass_count": int(sum(row["joint_qos_pass"] for row in rows)),
        "delivery_pass_count": int(sum(row["delivery_pass"] for row in rows)),
        "stale_pass_count": int(sum(row["stale_pass"] for row in rows)),
        "fairness_pass_count": int(sum(row["fairness_pass"] for row in rows)),
        "fnd_events": int(sum(row["fnd_event_observed"] for row in rows)),
        "mean_restricted_fnd_free_steps": float(np.mean([row["fnd_free_steps"] for row in rows])),
        "mean_delivery_ratio": float(np.mean([row["delivery_ratio"] for row in rows])),
        "mean_stale_ratio": float(np.mean([row["stale_ratio"] for row in rows])),
        "mean_episode_service_fairness": float(np.mean([row["episode_service_fairness"] for row in rows])),
        "mean_global_packets_per_j": float(np.mean([row["global_packets_per_j"] for row in rows])),
        "fairness_distribution": distribution([row["episode_service_fairness"] for row in rows]),
    }


def evaluate_candidate(contract, exponent):
    """Evaluate one frozen exponent in an isolated CPU process."""
    seeds = [int(seed) for seed in contract["development_seeds"]]
    risk = validate_ch_risk_config(json.loads(resolve(contract["risk_config"]).read_text()))
    qos = Step3QoSConstraintConfig.from_payload(
        json.loads(resolve(contract["qos_config"]).read_text())
    )
    local_contract = {
        "budget": int(contract["budget"]),
        "horizon": int(contract["horizon"]),
        "baseline_parameters": {
            "energy_proportional_score_exponent": float(exponent),
            "s2a2mac_energy_weight": 0.25,
        },
    }
    environments, _, _ = build_environments(
        resolve(contract["environment_profile"]), risk,
        int(contract["horizon"]), seeds=seeds,
    )
    expected = len(seeds) * int(contract["target_ranks_per_seed"])
    if len(environments) != expected:
        raise RuntimeError(f"expected {expected} development pairs, got {len(environments)}")
    rows = evaluate("energy_proportional", environments, None, qos, None, local_contract)
    for row in rows:
        row["energy_score_exponent"] = float(exponent)
    return {
        "energy_score_exponent": float(exponent),
        "aggregate": aggregate(rows),
        "per_seed": {
            str(seed): aggregate([row for row in rows if int(row["seed"]) == seed])
            for seed in seeds
        },
        "rows": rows,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path, output_path = resolve(args.contract), resolve(args.output)
    contract = json.loads(contract_path.read_text())
    if contract.get("status") != "frozen_before_development_sweep":
        raise RuntimeError("development sweep contract is not frozen")
    for field in ("environment_profile", "risk_config", "qos_config"):
        if sha256(contract[field]) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"development sweep artifact hash mismatch: {field}")
    seeds = [int(seed) for seed in contract["development_seeds"]]
    forbidden = set(seeds) & set(contract["prohibited_seeds"])
    if forbidden:
        raise RuntimeError(f"forbidden seed in development sweep: {sorted(forbidden)}")
    started = time.perf_counter()
    candidates = []
    all_rows = []
    exponents = [float(value) for value in contract["energy_score_exponents"]]
    with concurrent.futures.ProcessPoolExecutor(max_workers=len(exponents)) as pool:
        futures = {
            pool.submit(evaluate_candidate, contract, exponent): exponent
            for exponent in exponents
        }
        for future in concurrent.futures.as_completed(futures):
            candidate = future.result()
            rows = candidate.pop("rows")
            candidates.append(candidate)
            all_rows.extend(rows)
            summary = candidate["aggregate"]
            print(
                f"EXPONENT={candidate['energy_score_exponent']:.3f} "
                f"JOINT={summary['joint_qos_pass_count']}/{summary['pairs']} "
                f"FND={summary['mean_restricted_fnd_free_steps']:.4f} "
                f"DELIVERY={summary['mean_delivery_ratio']:.6f} "
                f"FAIRNESS={summary['mean_episode_service_fairness']:.6f}",
                flush=True,
            )
    candidates.sort(key=lambda item: item["energy_score_exponent"])
    all_rows.sort(key=lambda row: (row["energy_score_exponent"], row["seed"], row["target_rank"]))
    selected = max(
        candidates,
        key=lambda item: (
            item["aggregate"]["joint_qos_pass_count"],
            item["aggregate"]["mean_restricted_fnd_free_steps"],
            item["aggregate"]["mean_delivery_ratio"],
            item["aggregate"]["mean_global_packets_per_j"],
            -item["energy_score_exponent"],
        ),
    )
    payload = {
        "schema_version": 1,
        "status": "development_sweep_complete_baseline_selected",
        "contract_sha256": sha256(contract_path),
        "evaluator_sha256": sha256(Path(__file__)),
        "development_only": True,
        "inferential_claim_permitted": False,
        "seeds": seeds,
        "candidates": candidates,
        "selected_energy_score_exponent": selected["energy_score_exponent"],
        "selection_rule": contract["selection_rule"],
        "prospective_fairness_threshold_status": contract["prospective_fairness"],
        "all_candidate_fairness_distribution": distribution(
            [row["episode_service_fairness"] for row in all_rows]
        ),
        "rows": all_rows,
        "elapsed_seconds": time.perf_counter() - started,
        "reserved_confirmation_seeds_opened": False,
        "claim_boundary": contract["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(f"SELECTED_EXPONENT={payload['selected_energy_score_exponent']}", flush=True)
    print(f"OUTPUT={output_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
