"""No-learning primary-profile QoS reachability probe after transfer failure."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.ch_depletion_risk import validate_ch_risk_config
from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from experiments.diagnose_step3_delivery_feasibility import (
    aggregate,
    build_environments,
    evaluate_policy,
    load_agent,
)


def resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path: str | Path) -> str:
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--direction-contract", type=Path, required=True)
    parser.add_argument("--qos-config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path = resolve(args.direction_contract)
    qos_path = resolve(args.qos_config)
    output_path = resolve(args.output)
    contract = json.loads(contract_path.read_text())
    if contract.get("status") != "frozen_before_primary_direction_check":
        raise RuntimeError("primary direction contract is not frozen")
    if int(contract["seed"]) in set(contract["prohibited_seeds"]):
        raise RuntimeError("prohibited seed requested")
    risk = validate_ch_risk_config(json.loads(resolve(contract["risk_config"]).read_text()))
    qos = Step3QoSConstraintConfig.from_payload(json.loads(qos_path.read_text()))
    agent, checkpoint = load_agent(resolve(contract["hta_checkpoint"]))
    environments, manifest, cfg = build_environments(
        None, risk, int(contract["horizon"]), seeds=(int(contract["seed"]),)
    )
    rows = evaluate_policy(
        "fair_budget_fill_oracle", environments, agent, qos, cfg.frame_slot_budget
    )
    result = aggregate(rows, qos)
    reachable_pairs = sum(row["delivery_ratio"] >= qos.minimum_delivery_ratio for row in rows)
    reachable = reachable_pairs == len(rows)
    payload = {
        "schema_version": 1,
        "status": "primary_qos_floor_reachable" if reachable else "primary_qos_floor_not_reachable_stop_transfer",
        "development_only": True,
        "no_learning": True,
        "direction_contract_sha256": sha256(contract_path),
        "evaluator_sha256": sha256(Path(__file__)),
        "qos_config_sha256": sha256(qos_path),
        "checkpoint_sha256": sha256(contract["hta_checkpoint"]),
        "checkpoint_episode": checkpoint.get("metadata", {}).get("episode"),
        "seed": int(contract["seed"]),
        "target_ranks": list(range(len(manifest))),
        "horizon": int(contract["horizon"]),
        "budget": int(cfg.frame_slot_budget),
        "delivery_floor": qos.minimum_delivery_ratio,
        "delivery_floor_pass_pairs": int(reachable_pairs),
        "oracle": result,
        "rows": rows,
        "training_or_confirmation_authorized": False,
        "required_next_action": (
            "freeze a development-only primary-profile feasibility and constraint redesign; "
            "do not transfer B16 thresholds or open confirmation seeds"
        ),
        "remaining_confirmation_seeds_opened": False,
        "claim_boundary": "no-learning single-development-seed capacity probe, not model performance",
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"status": payload["status"], "oracle": result}, indent=2))
    print(f"OUTPUT={output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
