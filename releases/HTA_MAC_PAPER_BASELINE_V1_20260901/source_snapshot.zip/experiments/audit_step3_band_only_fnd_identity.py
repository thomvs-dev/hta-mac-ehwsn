"""Physical FND-node audit for seed-3400 HTA-MAC versus band-only."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import experiments.train_phase2_dynamic_curriculum as trainer
from agents.ch_depletion_risk import validate_ch_risk_config
from experiments.diagnose_step3_delivery_feasibility import build_environments, load_agent
from experiments.evaluate_step3_common_horizon_ablation import band_only_action
from experiments.sweep_step3_qos_band_projection import qos_band_projection


def resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path: str | Path) -> str:
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def load_contract(path: Path) -> dict:
    contract = json.loads(path.read_text())
    if contract.get("status") != "frozen_before_fnd_identity_audit":
        raise RuntimeError("FND identity contract is not frozen")
    for field in (
        "hta_checkpoint", "band_config", "environment_profile", "risk_config",
        "common_horizon_result",
    ):
        if sha256(contract[field]) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"artifact hash mismatch: {field}")
    if int(contract["seed"]) in set(contract["prohibited_seeds"]):
        raise RuntimeError("prohibited seed requested")
    return contract


def run_policy(contract_path_string, policy):
    contract = load_contract(resolve(contract_path_string))
    torch.set_num_threads(int(contract["threads_per_worker"]))
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    risk = validate_ch_risk_config(json.loads(resolve(contract["risk_config"]).read_text()))
    band = json.loads(resolve(contract["band_config"]).read_text())
    agent, _ = load_agent(resolve(contract["hta_checkpoint"]))
    envs, _, _ = build_environments(
        resolve(contract["environment_profile"]), risk, int(contract["horizon"]),
        seeds=(int(contract["seed"]),),
    )
    records = []
    for env in envs:
        observation, mask, _ = env.reset()
        n = env.base.n_nodes
        ch_assignments = np.zeros(n, dtype=np.int64)
        total_consumed = np.zeros(n, dtype=np.float64)
        member_tx_energy = np.zeros(n, dtype=np.float64)
        ch_forwarding_energy = np.zeros(n, dtype=np.float64)
        allocated_slots = np.zeros(n, dtype=np.int64)
        delivered_packets = np.zeros(n, dtype=np.int64)
        done = False
        death_record = None
        while not done:
            alive_before = env.base.alive.copy()
            energy_before = env.base.energy.copy()
            queue_before = env.base.queue.copy()
            positions_before = env.base.positions.copy()
            members, ch = env.members.copy(), int(env.ch)
            heads_before = env.base.cluster_heads.copy()
            cluster_before = env.base.cluster_of.copy()
            ch_assignments[heads_before] += 1
            padded, padded_mask, caps = trainer.padded_state(
                env, observation, mask, env.base.n_nodes
            )
            if policy == "hta_mac_qos_band":
                base, q_values = agent.act(
                    padded, padded_mask, epsilon=0.0, caps=caps,
                    budget=int(contract["budget"]),
                    tie_break_priorities=np.arange(n),
                )
                action, _ = qos_band_projection(
                    base, q_values, caps, padded_mask, env,
                    lower_target=float(band["lower_delivery_target"]),
                    upper_target=float(band["upper_delivery_target"]),
                    reserve_floor=float(band["reserve_floor"]),
                    completion_fraction=float(band["completion_fraction"]),
                )
            elif policy == "band_only_energy_proportional":
                action, _ = band_only_action(
                    env, padded_mask, caps, int(contract["budget"]),
                    float(contract["energy_score_exponent"]), band,
                )
            else:
                raise ValueError(policy)
            allocated_slots += action
            observation, mask, done, info = env.step(action)
            trace = info["energy_trace"]
            roles = trace["role_energy"]
            consumed = np.asarray(trace["consumed"], dtype=np.float64)
            member_energy = np.asarray(roles["member_tx"], dtype=np.float64)
            forwarding = (
                np.asarray(roles["ch_rx"], dtype=np.float64)
                + np.asarray(roles["ch_aggregate"], dtype=np.float64)
                + np.asarray(roles["ch_tx_bs"], dtype=np.float64)
            )
            delivered = np.asarray(info["delivered_packets_per_node"], dtype=np.int64)
            total_consumed += consumed
            member_tx_energy += member_energy
            ch_forwarding_energy += forwarding
            delivered_packets += delivered
            newly_dead = np.flatnonzero(alive_before & ~env.base.alive)
            if newly_dead.size:
                nodes = []
                head_set = set(int(value) for value in heads_before)
                for node_value in newly_dead:
                    node = int(node_value)
                    cluster = int(cluster_before[node])
                    nodes.append({
                        "node_id": node,
                        "position_m": positions_before[node].tolist(),
                        "distance_to_bs_m": float(np.linalg.norm(
                            positions_before[node] - np.asarray(env.base.cfg.bs_position_m)
                        )),
                        "was_ch_on_fnd_round": node in head_set,
                        "was_target_ch_on_fnd_round": node == ch,
                        "was_target_member_on_fnd_round": node in set(int(x) for x in members),
                        "cluster_on_fnd_round": cluster,
                        "scheduled_ch_on_fnd_round": int(heads_before[cluster]),
                        "energy_before_j": float(energy_before[node]),
                        "energy_after_j": float(env.base.energy[node]),
                        "queue_before": int(queue_before[node]),
                        "allocated_slots_on_fnd_round": int(action[node]),
                        "delivered_on_fnd_round": int(delivered[node]),
                        "consumed_on_fnd_round_j": float(consumed[node]),
                        "member_tx_on_fnd_round_j": float(member_energy[node]),
                        "ch_forwarding_on_fnd_round_j": float(forwarding[node]),
                        "harvested_on_fnd_round_j": float(trace["harvested"][node]),
                        "ch_assignments_through_fnd": int(ch_assignments[node]),
                        "ch_assignment_fraction_through_fnd": float(ch_assignments[node] / env.base.round),
                        "cumulative_total_consumed_j": float(total_consumed[node]),
                        "cumulative_member_tx_energy_j": float(member_tx_energy[node]),
                        "cumulative_ch_forwarding_energy_j": float(ch_forwarding_energy[node]),
                        "cumulative_allocated_slots": int(allocated_slots[node]),
                        "cumulative_delivered_packets": int(delivered_packets[node]),
                    })
                death_record = {
                    "fnd_round": int(env.base.t_fnd),
                    "newly_dead_count": int(newly_dead.size),
                    "newly_dead_nodes": nodes,
                }
        records.append({
            "seed": int(env.seed), "target_rank": int(env.target_rank),
            "policy": policy, "rounds": int(env.base.round),
            "fnd_event_observed": death_record is not None,
            "right_censored_at_horizon": death_record is None,
            "death": death_record,
        })
    return policy, records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path, output_path = resolve(args.contract), resolve(args.output)
    contract = load_contract(contract_path)
    source = json.loads(resolve(contract["common_horizon_result"]).read_text())
    source_final = {
        (row["policy"], int(row["target_rank"])): int(row["fnd_free_steps"])
        for row in source["final_survival_rows"]
        if row["policy"] in contract["policies"]
    }
    started = time.perf_counter()
    records = []
    with concurrent.futures.ProcessPoolExecutor(
        max_workers=int(contract["policy_workers"])
    ) as pool:
        futures = [pool.submit(run_policy, str(contract_path), policy) for policy in contract["policies"]]
        for future in concurrent.futures.as_completed(futures):
            policy, rows = future.result()
            records.extend(rows)
            print(f"POLICY_COMPLETE={policy}", flush=True)
    for row in records:
        observed = row["death"]["fnd_round"] if row["death"] else int(contract["horizon"])
        expected = source_final[(row["policy"], row["target_rank"])]
        if observed != expected:
            raise RuntimeError(
                f"FND replay mismatch policy={row['policy']} rank={row['target_rank']}: "
                f"expected {expected}, observed {observed}"
            )
    indexed = {
        policy: {row["target_rank"]: row for row in records if row["policy"] == policy}
        for policy in contract["policies"]
    }
    left, right = contract["policies"]
    paired = []
    counts = {"hta_wins": 0, "ties": 0, "hta_losses": 0}
    for rank in range(int(contract["target_ranks"])):
        lrow, rrow = indexed[left][rank], indexed[right][rank]
        lfnd = lrow["death"]["fnd_round"] if lrow["death"] else int(contract["horizon"])
        rfnd = rrow["death"]["fnd_round"] if rrow["death"] else int(contract["horizon"])
        category = "hta_wins" if lfnd > rfnd else "hta_losses" if lfnd < rfnd else "ties"
        counts[category] += 1
        lnodes = set(n["node_id"] for n in lrow["death"]["newly_dead_nodes"]) if lrow["death"] else set()
        rnodes = set(n["node_id"] for n in rrow["death"]["newly_dead_nodes"]) if rrow["death"] else set()
        paired.append({
            "target_rank": rank, "category": category,
            "hta_fnd": lfnd, "band_only_fnd": rfnd, "hta_minus_band_only_fnd": lfnd - rfnd,
            "hta_dying_nodes": sorted(lnodes), "band_only_dying_nodes": sorted(rnodes),
            "same_dying_node_set": lnodes == rnodes and bool(lnodes),
            "any_dying_node_overlap": bool(lnodes.intersection(rnodes)),
            "hta_death": lrow["death"], "band_only_death": rrow["death"],
        })
    if counts != contract["required_rank_split"]:
        raise RuntimeError(f"rank split changed: {counts}")
    loss_rows = [row for row in paired if row["category"] == "hta_losses"]
    summary = {
        "rank_split": counts,
        "event_pairs_both_observed": sum(bool(row["hta_death"] and row["band_only_death"]) for row in paired),
        "same_dying_node_set_pairs": sum(row["same_dying_node_set"] for row in paired),
        "overlapping_dying_node_pairs": sum(row["any_dying_node_overlap"] for row in paired),
        "hta_loss_ranks": [row["target_rank"] for row in loss_rows],
        "hta_loss_same_dying_node_count": sum(row["same_dying_node_set"] for row in loss_rows),
        "hta_loss_hta_died_as_ch_count": sum(
            any(node["was_ch_on_fnd_round"] for node in row["hta_death"]["newly_dead_nodes"])
            for row in loss_rows
        ),
        "hta_loss_hta_died_as_target_ch_count": sum(
            any(node["was_target_ch_on_fnd_round"] for node in row["hta_death"]["newly_dead_nodes"])
            for row in loss_rows
        ),
    }
    payload = {
        "schema_version": 1,
        "status": "seed3400_band_only_fnd_identity_audit_complete",
        "contract_sha256": sha256(contract_path),
        "evaluator_sha256": sha256(Path(__file__)),
        "source_result_sha256": sha256(contract["common_horizon_result"]),
        "all_fnd_rounds_reproduced": True,
        "summary": summary,
        "paired_ranks": paired,
        "records": sorted(records, key=lambda row: (row["policy"], row["target_rank"])),
        "elapsed_seconds": time.perf_counter() - started,
        "remaining_confirmation_seeds_opened": False,
        "inferential_claim_permitted": False,
        "claim_boundary": contract["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(summary, indent=2), flush=True)
    print(f"OUTPUT={output_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
