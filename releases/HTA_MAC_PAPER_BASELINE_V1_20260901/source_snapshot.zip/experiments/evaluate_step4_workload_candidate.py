"""Fresh-seed workload transfer evaluation with paired uncertainty estimates."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import experiments.train_phase2_dynamic_curriculum as trainer
from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from envs.step3_policy_observation import STEP3_CH_CONTEXT_SCHEMA, STEP3_WORKLOAD_CONTEXT_SCHEMA
from experiments.diagnose_step3_delivery_feasibility import load_agent
from experiments.evaluate_step3_final_matched_baselines import energy_proportional_action
from experiments.evaluate_step4_publication_evidence import build_transfer_environments


SCENARIOS = (
    {"id": "reference_100", "nodes": 100, "field_scale": 1.0, "arrival_rate": 1.0, "harvest_multiplier": 1.0, "initial_energy_multiplier": 1.0},
    {"id": "nodes_20", "nodes": 20, "field_scale": 1.0, "arrival_rate": 1.0, "harvest_multiplier": 1.0, "initial_energy_multiplier": 1.0},
    {"id": "traffic_low", "nodes": 100, "field_scale": 1.0, "arrival_rate": 0.5, "harvest_multiplier": 1.0, "initial_energy_multiplier": 1.0},
    {"id": "traffic_high", "nodes": 100, "field_scale": 1.0, "arrival_rate": 1.5, "harvest_multiplier": 1.0, "initial_energy_multiplier": 1.0},
    {"id": "harvest_low", "nodes": 100, "field_scale": 1.0, "arrival_rate": 1.0, "harvest_multiplier": 0.5, "initial_energy_multiplier": 1.0},
    {"id": "battery_half", "nodes": 100, "field_scale": 1.0, "arrival_rate": 1.0, "harvest_multiplier": 1.0, "initial_energy_multiplier": 0.5},
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def evaluate(policy, envs, qos, budget=24):
    rows = []
    agent = None if policy == "energy_proportional" else load_agent(policy)[0]
    for env in envs:
        observation, mask, _ = env.reset()
        energy = 0.0
        done = False
        while not done:
            state, active, caps = trainer.padded_state(env, observation, mask, env.base.n_nodes)
            if agent is None:
                action = energy_proportional_action(env, active, budget, 4.0)
            else:
                action, _ = agent.act(state, active, epsilon=0.0, caps=caps, budget=budget)
            observation, mask, done, info = env.step(action)
            energy += float(np.asarray(info["energy_trace"]["consumed"]).sum())
        counts = env.step3_qos_counts
        demand = max(1, int(counts["demand"]))
        delivery = int(counts["delivered"]) / demand
        stale = int(counts["stale"]) / demand
        fairness = float(counts["episode_service_fairness"])
        rows.append({
            "seed": int(env.seed), "target_rank": int(env.target_rank),
            "delivery_ratio": delivery, "stale_ratio": stale, "fairness": fairness,
            "joint_qos_pass": bool(delivery >= qos.minimum_delivery_ratio and stale <= qos.maximum_stale_drop_ratio and fairness >= qos.minimum_queue_fairness),
            "restricted_survival_rounds": int(env.base.t_fnd if env.base.t_fnd is not None else env.base.round),
            "global_packets": int(env.base.total_packets), "network_energy_j": energy,
            "packets_per_j": int(env.base.total_packets) / max(energy, 1e-12),
        })
    return rows


def seed_means(rows):
    result = {}
    for seed in sorted({row["seed"] for row in rows}):
        subset = [row for row in rows if row["seed"] == seed]
        result[seed] = {
            key: float(np.mean([row[key] for row in subset]))
            for key in ("delivery_ratio", "stale_ratio", "fairness", "restricted_survival_rounds", "global_packets", "network_energy_j", "packets_per_j")
        }
        result[seed]["joint_qos_pass_rate"] = float(np.mean([row["joint_qos_pass"] for row in subset]))
    return result


def paired_stats(candidate, baseline, metric, rng):
    seeds = sorted(set(candidate) & set(baseline))
    differences = np.asarray([candidate[s][metric] - baseline[s][metric] for s in seeds])
    draws = rng.choice(differences, size=(10000, len(differences)), replace=True).mean(axis=1)
    try:
        p_value = float(wilcoxon(differences, alternative="two-sided").pvalue)
    except ValueError:
        p_value = 1.0
    return {
        "n_seed_pairs": len(seeds), "mean_difference": float(differences.mean()),
        "bootstrap_95_ci": [float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))],
        "wilcoxon_two_sided_p": p_value,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seeds", default="3980,3981,3982,3983,3984")
    parser.add_argument("--horizon", type=int, default=3000)
    args = parser.parse_args()
    candidate, source = args.candidate.resolve(), args.source.resolve()
    seeds = [int(value) for value in args.seeds.split(",")]
    sealed = set(range(3900, 3920))
    if set(seeds) & sealed:
        raise RuntimeError("sealed confirmation seeds were requested")
    qos_path = ROOT / "config" / "step3_primary_qos_candidate_v1.json"
    qos = Step3QoSConstraintConfig.from_payload(json.loads(qos_path.read_text()))
    base_contract = {
        "horizon": args.horizon, "development_seeds": seeds,
        "risk_config": "config/step3_v3_risk_weight_5.json",
    }
    policies = {"candidate": candidate, "source": source, "energy_proportional": "energy_proportional"}
    results = {}
    rng = np.random.default_rng(20260815)
    for scenario in SCENARIOS:
        results[scenario["id"]] = {}
        for name, policy in policies.items():
            contract = dict(base_contract)
            contract["observation_schema"] = STEP3_WORKLOAD_CONTEXT_SCHEMA if name == "candidate" else STEP3_CH_CONTEXT_SCHEMA
            envs = build_transfer_environments(contract, scenario)
            rows = evaluate(policy, envs, qos)
            means = seed_means(rows)
            results[scenario["id"]][name] = {"rows": rows, "seed_means": means}
        candidate_means = results[scenario["id"]]["candidate"]["seed_means"]
        source_means = results[scenario["id"]]["source"]["seed_means"]
        results[scenario["id"]]["candidate_vs_source"] = {
            metric: paired_stats(candidate_means, source_means, metric, rng)
            for metric in ("delivery_ratio", "restricted_survival_rounds", "packets_per_j")
        }
    payload = {
        "schema_version": 1, "status": "fresh_development_evaluation_complete",
        "candidate": str(candidate), "candidate_sha256": sha256(candidate),
        "source": str(source), "source_sha256": sha256(source),
        "seeds": seeds, "horizon": args.horizon, "confirmation_seeds_opened": False,
        "results": results,
        "inference_boundary": "five development seeds; paired uncertainty is descriptive and cannot establish p<0.05 for same-direction nonzero differences",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"EVALUATION_COMPLETE={args.output}")


if __name__ == "__main__":
    main()
