"""Frozen one-seed primary idle-on/hybrid mechanism direction check."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.ch_depletion_risk import validate_ch_risk_config
from experiments.diagnose_step3_delivery_feasibility import build_environments, load_agent
from experiments.evaluate_step3_common_horizon_ablation import (
    paired_common_horizon,
    run_policy,
    summarize_common,
)


def resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path: str | Path) -> str:
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def load_contract(path: Path) -> dict:
    contract = json.loads(path.read_text())
    if contract.get("status") != "frozen_before_primary_direction_check":
        raise RuntimeError("primary direction-check contract is not frozen")
    for field in (
        "hta_checkpoint", "band_config", "risk_config", "primary_base_config",
        "primary_phase1_config", "frozen_assets_manifest",
    ):
        if sha256(contract[field]) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"artifact hash mismatch: {field}")
    if int(contract["seed"]) in set(contract["prohibited_seeds"]):
        raise RuntimeError("prohibited seed requested")
    if contract["retraining_or_retuning_permitted"] is not False:
        raise RuntimeError("direction check must not retune")
    return contract


def worker(contract_path_string, policy):
    contract = load_contract(resolve(contract_path_string))
    torch.set_num_threads(int(contract["threads_per_worker"]))
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    risk = validate_ch_risk_config(json.loads(resolve(contract["risk_config"]).read_text()))
    band = json.loads(resolve(contract["band_config"]).read_text())
    agent, _ = load_agent(resolve(contract["hta_checkpoint"]))
    environments, manifest, cfg = build_environments(
        None, risk, int(contract["horizon"]), seeds=(int(contract["seed"]),)
    )
    if cfg.frame_slot_budget != int(contract["budget"]):
        raise RuntimeError("primary budget changed")
    return policy, run_policy(policy, environments, agent, band, contract), manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path, output_path = resolve(args.contract), resolve(args.output)
    contract = load_contract(contract_path)
    _, checkpoint = load_agent(resolve(contract["hta_checkpoint"]))
    started = time.perf_counter()
    all_runs, manifest = {}, None
    with concurrent.futures.ProcessPoolExecutor(
        max_workers=int(contract["policy_workers"])
    ) as pool:
        futures = [pool.submit(worker, str(contract_path), policy) for policy in contract["policies"]]
        for future in concurrent.futures.as_completed(futures):
            policy, runs, local_manifest = future.result()
            all_runs[policy] = runs
            manifest = local_manifest
            print(f"POLICY_COMPLETE={policy}", flush=True)
    target_ranks = sorted(all_runs[contract["policies"][0]])
    if len(target_ranks) != len(manifest):
        raise RuntimeError("primary target-rank coverage changed")
    common, post_tau = paired_common_horizon(all_runs, contract["policies"])
    final = [
        all_runs[policy][rank]["final"]
        for policy in contract["policies"] for rank in target_ranks
    ]
    payload = {
        "schema_version": 1,
        "status": "primary_idle_on_hybrid_direction_check_complete",
        "contract_sha256": sha256(contract_path),
        "evaluator_sha256": sha256(Path(__file__)),
        "checkpoint_sha256": sha256(contract["hta_checkpoint"]),
        "checkpoint_episode": checkpoint.get("metadata", {}).get("episode"),
        "seed": int(contract["seed"]),
        "target_ranks": target_ranks,
        "target_ranks_are_independent_trials": False,
        "environment_manifest": manifest,
        "primary_regime": contract["primary_regime"],
        "common_horizon_definition": "per target rank tau=min(policy termination rounds); both cumulative endpoints sampled exactly at tau",
        "common_horizon_summary": summarize_common(common),
        "common_horizon_rows": common,
        "post_common_horizon_behavior": post_tau,
        "final_survival_rows": final,
        "direction_check_only": True,
        "selection_or_retuning_performed": False,
        "inferential_claim_permitted": False,
        "remaining_confirmation_seeds_opened": False,
        "elapsed_seconds": time.perf_counter() - started,
        "claim_boundary": contract["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(f"OUTPUT={output_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
