"""Frozen fresh-seed base training for the Step 3 QoS-band confirmation."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import experiments.train_step3_qos_deficit_complete as base


def _resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def _required_value(arguments, flag):
    if flag not in arguments:
        raise RuntimeError(f"confirmation CLI is missing {flag}")
    return arguments[arguments.index(flag) + 1]


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--confirmation-contract", type=Path, required=True)
    known, remaining = parser.parse_known_args()
    contract_path = _resolve(known.confirmation_contract)
    contract = json.loads(contract_path.read_text())
    if contract.get("status") != "frozen_before_reserved_confirmation":
        raise RuntimeError("confirmation contract is not frozen")
    checks = {
        "--episodes": int(contract["episodes"]),
        "--max-steps": int(contract["horizon"]),
        "--optimizer-seed": int(contract["base_optimizer_seed"]),
        "--projection-budget": int(contract["budget"]),
    }
    for flag, expected in checks.items():
        if int(_required_value(remaining, flag)) != expected:
            raise RuntimeError(f"confirmation CLI contract changed: {flag}")
    requested_seeds = [
        int(value) for value in _required_value(remaining, "--development-seeds").split(",")
    ]
    if requested_seeds != [int(contract["confirmation_seed"])]:
        raise RuntimeError("confirmation training must use exactly the frozen seed")
    if set(requested_seeds) & set(contract["prohibited_registered_held_out_seeds"]):
        raise RuntimeError("registered held-out seed requested")
    expected_paths = {
        "--qos-deficit-config": "base_controller_config",
        "--ch-risk-config": "risk_config",
        "--step3-qos-config": "qos_config",
        "--runtime-contract": "runtime_contract",
        "--preflight-report": "preflight_report",
        "--reward-scale-config": "reward_scale_config",
        "--environment-profile": "environment_profile",
    }
    for flag, field in expected_paths.items():
        actual = _resolve(_required_value(remaining, flag)).resolve()
        expected = _resolve(contract[field]).resolve()
        if actual != expected:
            raise RuntimeError(f"confirmation path contract changed: {flag}")
        if base.complete.v3.sha256(actual) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"confirmation artifact hash mismatch: {field}")

    controller_path = _resolve(contract["base_controller_config"])
    controller = json.loads(controller_path.read_text())
    if controller.get("status") != "frozen_selected_qos_deficit_candidate":
        raise RuntimeError("base controller is not the frozen selected candidate")
    base._CONTROLLER_CONFIG = controller
    for key in base._CONTROLLER_TOTALS:
        base._CONTROLLER_TOTALS[key] = 0
    base.complete.EnergyAuditedStep3V3Env = base.QoSDeficitTrainingEnv
    base.complete.v3.RecoveryExportAgent = base.QoSDeficitAgent
    forwarded = list(remaining)
    index = forwarded.index("--qos-deficit-config")
    del forwarded[index:index + 2]
    sys.argv = [sys.argv[0], *forwarded]
    result = base.complete.main()

    run_name = _required_value(forwarded, "--run-name")
    summary_path = ROOT / "outputs" / "phase2" / run_name / "summary.json"
    if summary_path.is_file():
        summary = json.loads(summary_path.read_text())
        summary["confirmation_base_training"] = {
            "contract_path": str(contract_path.resolve()),
            "contract_sha256": base.complete.v3.sha256(contract_path),
            "confirmation_seed": contract["confirmation_seed"],
            "base_optimizer_seed": contract["base_optimizer_seed"],
            "controller_config_sha256": contract["base_controller_config_sha256"],
            "totals": dict(base._CONTROLLER_TOTALS),
            "fresh_training_not_checkpoint_reuse": True,
        }
        summary_path.write_text(json.dumps(summary, indent=2) + "\n")
        export_dir = _resolve(_required_value(forwarded, "--checkpoint-export-dir"))
        export_summary = export_dir / "summary.json"
        export_summary.write_text(summary_path.read_text())
    return result


if __name__ == "__main__":
    raise SystemExit(main())
