"""Seed-3400 common-horizon comparison with a no-neural QoS-band ablation."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import experiments.train_phase2_dynamic_curriculum as trainer
from agents.budget_projection import project_slot_budget
from agents.ch_depletion_risk import validate_ch_risk_config
from agents.qos_constraints_v3 import Step3QoSConstraintConfig
from experiments.diagnose_step3_delivery_feasibility import build_environments, load_agent
from experiments.evaluate_step3_qos_band_matched_baselines import (
    energy_proportional_action,
    s2a2mac_action,
)
from experiments.sweep_step3_qos_band_projection import qos_band_projection


def resolve(path: str | Path) -> Path:
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def sha256(path: str | Path) -> str:
    return hashlib.sha256(resolve(path).read_bytes()).hexdigest()


def load_contract(path: Path) -> dict:
    contract = json.loads(path.read_text())
    if contract.get("status") != "frozen_before_common_horizon_ablation":
        raise RuntimeError("common-horizon contract is not frozen")
    for field in (
        "hta_checkpoint", "band_config", "environment_profile", "risk_config",
        "qos_config", "development_sweep_result",
    ):
        if sha256(contract[field]) != contract[f"{field}_sha256"]:
            raise RuntimeError(f"common-horizon artifact hash mismatch: {field}")
    expected = [
        "hta_mac_qos_band", "energy_proportional_tuned",
        "band_only_energy_proportional", "s2a2mac_adapted",
    ]
    if contract["policies"] != expected:
        raise RuntimeError("common-horizon policy set changed")
    development = json.loads(resolve(contract["development_sweep_result"]).read_text())
    tuned = float(development["selected_energy_score_exponent"])
    if tuned != float(contract["baseline_parameters"]["energy_proportional_score_exponent"]):
        raise RuntimeError("tuned exponent does not match frozen development result")
    return contract


def band_only_action(env, mask, caps, budget, exponent, band):
    """Energy-proportional marginal utility followed by the identical QoS band.

    This controller contains no network weights, logits, or checkpoint-derived
    quantities.  Its diminishing marginal score is energy**exponent / level.
    """
    mask = np.asarray(mask, dtype=bool)
    caps = np.asarray(caps, dtype=np.int64)
    levels = env.base.cfg.n_max + 1
    q_values = np.zeros((env.base.n_nodes, levels), dtype=np.float64)
    scores = np.power(
        np.clip(env.base.energy / env.base.cfg.initial_energy_j, 0.0, 1.0),
        float(exponent),
    )
    for node in range(env.base.n_nodes):
        for level in range(1, levels):
            valid = bool(mask[node]) and level <= int(caps[node])
            gain = scores[node] / float(level) if valid else -1.0e6
            q_values[node, level] = q_values[node, level - 1] + gain
    base_action = project_slot_budget(
        q_values, int(budget), stop_at_nonpositive_gain=True,
        tie_break_priorities=np.arange(env.base.n_nodes),
    )
    return qos_band_projection(
        base_action, q_values, caps, mask, env,
        lower_target=float(band["lower_delivery_target"]),
        upper_target=float(band["upper_delivery_target"]),
        reserve_floor=float(band["reserve_floor"]),
        completion_fraction=float(band["completion_fraction"]),
    )


def snapshot(env, total_energy, target_role_energy, allocated_slots):
    counts = env.step3_qos_counts
    demand = int(counts["demand"])
    delivered = int(counts["delivered"])
    stale = int(counts["stale"])
    return {
        "round": int(env.base.round),
        "target_packets_delivered": delivered,
        "target_packets_offered": demand,
        "target_stale_drops": stale,
        "delivery_ratio": delivered / max(1, demand),
        "stale_ratio": stale / max(1, demand),
        "episode_service_fairness": float(counts["episode_service_fairness"]),
        "global_packets_delivered": int(env.base.total_packets),
        "total_network_energy_j": float(total_energy),
        "target_role_energy_j": float(target_role_energy),
        "allocated_slots": int(allocated_slots),
    }


def run_policy(policy, environments, agent, band, contract):
    budget = int(contract["budget"])
    exponent = float(contract["baseline_parameters"]["energy_proportional_score_exponent"])
    energy_weight = float(contract["baseline_parameters"]["s2a2mac_energy_weight"])
    runs = {}
    for env in environments:
        observation, mask, _ = env.reset()
        total_energy = target_role_energy = 0.0
        allocated_slots = 0
        trajectory = []
        band_totals = {"added": 0, "removed": 0, "risk_blocked": 0}
        done = False
        while not done:
            members, ch = env.members.copy(), int(env.ch)
            padded, padded_mask, caps = trainer.padded_state(
                env, observation, mask, env.base.n_nodes
            )
            audit = None
            if policy == "hta_mac_qos_band":
                base, q_values = agent.act(
                    padded, padded_mask, epsilon=0.0, caps=caps, budget=budget,
                    tie_break_priorities=np.arange(env.base.n_nodes),
                )
                action, audit = qos_band_projection(
                    base, q_values, caps, padded_mask, env,
                    lower_target=float(band["lower_delivery_target"]),
                    upper_target=float(band["upper_delivery_target"]),
                    reserve_floor=float(band["reserve_floor"]),
                    completion_fraction=float(band["completion_fraction"]),
                )
            elif policy == "energy_proportional_tuned":
                action = energy_proportional_action(env, padded_mask, budget, exponent)
            elif policy == "band_only_energy_proportional":
                action, audit = band_only_action(
                    env, padded_mask, caps, budget, exponent, band
                )
            elif policy == "s2a2mac_adapted":
                action = s2a2mac_action(env, padded_mask, budget, energy_weight)
            else:
                raise ValueError(policy)
            if audit:
                for key in band_totals:
                    band_totals[key] += int(audit[key])
            allocated_slots += int(action.sum())
            observation, mask, done, info = env.step(action)
            trace = info["energy_trace"]
            total_energy += float(np.asarray(trace["consumed"]).sum())
            roles = trace["role_energy"]
            target_role_energy += float(roles["member_tx"][members].sum())
            target_role_energy += float(
                roles["ch_rx"][ch] + roles["ch_aggregate"][ch] + roles["ch_tx_bs"][ch]
            )
            trajectory.append(snapshot(env, total_energy, target_role_energy, allocated_slots))
        final = trajectory[-1]
        final.update({
            "seed": int(env.seed), "target_rank": int(env.target_rank), "policy": policy,
            "fnd_free_steps": int(env.base.t_fnd or contract["horizon"]),
            "fnd_event_observed": env.base.t_fnd is not None,
            "right_censored_fnd": env.base.t_fnd is None,
            "band_totals": band_totals if "band" in policy else None,
        })
        runs[int(env.target_rank)] = {"trajectory": trajectory, "final": final}
    return runs


def metrics_at(snapshot):
    rounds = max(1, int(snapshot["round"]))
    result = dict(snapshot)
    result.update({
        "global_packets_per_j": snapshot["global_packets_delivered"] / max(1e-12, snapshot["total_network_energy_j"]),
        "target_packets_per_role_j": snapshot["target_packets_delivered"] / max(1e-12, snapshot["target_role_energy_j"]),
        "global_packets_per_round": snapshot["global_packets_delivered"] / rounds,
        "target_packets_per_round": snapshot["target_packets_delivered"] / rounds,
        "network_energy_j_per_round": snapshot["total_network_energy_j"] / rounds,
        "target_role_energy_j_per_round": snapshot["target_role_energy_j"] / rounds,
        "allocated_slots_per_round": snapshot["allocated_slots"] / rounds,
    })
    return result


def paired_common_horizon(runs, policies):
    reference = policies[0]
    rows, post_tau = [], []
    for comparator in policies[1:]:
        for rank in sorted(runs[reference]):
            left, right = runs[reference][rank], runs[comparator][rank]
            tau = min(len(left["trajectory"]), len(right["trajectory"]))
            l_tau = metrics_at(left["trajectory"][tau - 1])
            r_tau = metrics_at(right["trajectory"][tau - 1])
            rows.append({
                "target_rank": rank, "reference": reference, "comparator": comparator,
                "common_horizon_tau": tau, "reference_at_tau": l_tau,
                "comparator_at_tau": r_tau,
            })
            for name, run, snap in ((reference, left, l_tau), (comparator, right, r_tau)):
                final = metrics_at(run["trajectory"][-1])
                if final["round"] > tau:
                    post_tau.append({
                        "target_rank": rank, "policy": name, "tau": tau,
                        "final_round": final["round"],
                        "additional_rounds": final["round"] - tau,
                        "additional_global_packets": final["global_packets_delivered"] - snap["global_packets_delivered"],
                        "additional_target_packets": final["target_packets_delivered"] - snap["target_packets_delivered"],
                        "additional_network_energy_j": final["total_network_energy_j"] - snap["total_network_energy_j"],
                        "note": "post-common-horizon behavior; excluded from matched cumulative comparison",
                    })
    return rows, post_tau


def summarize_common(rows):
    fields = (
        "delivery_ratio", "stale_ratio", "episode_service_fairness",
        "global_packets_per_j", "target_packets_per_role_j",
        "global_packets_per_round", "target_packets_per_round",
        "network_energy_j_per_round", "target_role_energy_j_per_round",
        "allocated_slots_per_round",
    )
    summaries = {}
    for comparator in sorted({row["comparator"] for row in rows}):
        subset = [row for row in rows if row["comparator"] == comparator]
        metrics = {}
        for field in fields:
            diffs = np.asarray([
                row["reference_at_tau"][field] - row["comparator_at_tau"][field]
                for row in subset
            ], dtype=np.float64)
            metrics[field] = {
                "orientation": "hta_mac_qos_band_minus_comparator",
                "mean_difference": float(diffs.mean()),
                "median_difference": float(np.median(diffs)),
                "wins": int(np.sum(diffs > 0)), "ties": int(np.sum(diffs == 0)),
                "losses": int(np.sum(diffs < 0)),
            }
        summaries[comparator] = {
            "pairs": len(subset),
            "mean_common_horizon_tau": float(np.mean([row["common_horizon_tau"] for row in subset])),
            "metrics": metrics,
        }
    return summaries


def evaluate_policy_from_contract(contract_path_string, policy):
    """Load immutable artifacts inside one worker and evaluate one policy."""
    contract_path = resolve(contract_path_string)
    contract = load_contract(contract_path)
    torch.set_num_threads(max(1, int(contract["threads_per_policy_worker"])))
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    risk = validate_ch_risk_config(json.loads(resolve(contract["risk_config"]).read_text()))
    band = json.loads(resolve(contract["band_config"]).read_text())
    agent, _ = load_agent(resolve(contract["hta_checkpoint"]))
    envs, _, _ = build_environments(
        resolve(contract["environment_profile"]), risk, int(contract["horizon"]),
        seeds=(int(contract["seed"]),),
    )
    return policy, run_policy(policy, envs, agent, band, contract)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    contract_path, output_path = resolve(args.contract), resolve(args.output)
    contract = load_contract(contract_path)
    _, checkpoint = load_agent(resolve(contract["hta_checkpoint"]))
    started = time.perf_counter()
    all_runs = {}
    workers = min(int(contract["policy_workers"]), len(contract["policies"]))
    with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
        futures = [
            pool.submit(evaluate_policy_from_contract, str(contract_path), policy)
            for policy in contract["policies"]
        ]
        for future in concurrent.futures.as_completed(futures):
            policy, runs = future.result()
            all_runs[policy] = runs
            print(f"POLICY_COMPLETE={policy}", flush=True)
    common, post_tau = paired_common_horizon(all_runs, contract["policies"])
    payload = {
        "schema_version": 1,
        "status": "common_horizon_and_band_only_ablation_complete",
        "contract_sha256": sha256(contract_path),
        "evaluator_sha256": sha256(Path(__file__)),
        "checkpoint_sha256": sha256(contract["hta_checkpoint"]),
        "checkpoint_episode": checkpoint.get("metadata", {}).get("episode"),
        "seed": int(contract["seed"]),
        "tuned_energy_score_exponent": contract["baseline_parameters"]["energy_proportional_score_exponent"],
        "common_horizon_definition": "per paired target rank and comparator, tau=min(policy termination rounds); cumulative endpoints sampled exactly at tau",
        "survival_endpoint_is_separate": True,
        "target_ranks_are_independent_trials": False,
        "inferential_claim_permitted": False,
        "common_horizon_summary": summarize_common(common),
        "common_horizon_rows": common,
        "post_common_horizon_behavior": post_tau,
        "final_survival_rows": [
            run["final"] for policy in contract["policies"]
            for run in all_runs[policy].values()
        ],
        "neural_content_of_band_only_controller": "none",
        "elapsed_seconds": time.perf_counter() - started,
        "remaining_reserved_confirmation_seeds_opened": False,
        "claim_boundary": contract["claim_boundary"],
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2) + "\n")
    print(f"OUTPUT={output_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
